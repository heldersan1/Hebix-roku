' Design System v2 - Modern TV UI for Roku
' Centralized colors, spacing, typography, and effects

function design() as object
  return {
    ' ===== COLOR PALETTE =====
    ' Backgrounds
    bgPrimary:       &h0D0D0DFF,  ' Near-black base
    bgSecondary:     &h1A1A1AFF,  ' Cards, panels
    bgTertiary:      &h242424FF,  ' Hover states
    bgOverlay:       &h000000CC,  ' Modal overlays
    
    ' Text
    textPrimary:     &hFFFFFFFF,  ' White
    textSecondary:   &hE0E0E0FF,  ' Light gray
    textMuted:       &hA0A0A0FF,  ' Medium gray
    textDisabled:    &h606060FF,  ' Dark gray
    
    ' Brand / Accent (Girassol yellow)
    accent:          &hFFC300FF,
    accentSoft:      &hFFC30080,
    accentGlow:      &hFFC30040,
    
    ' Semantic
    success:         &h4CAF50FF,
    warning:         &hFFB300FF,
    error:           &hF44336FF,
    info:            &h2196F3FF,
    
    ' ===== SPACING SCALE (4px base) =====
    space: {
      xs: 4,    ' 4px
      sm: 8,    ' 8px
      md: 16,   ' 16px
      lg: 24,   ' 24px
      xl: 32,   ' 32px
      xxl: 48,  ' 48px
    },
    
    ' ===== BORDER RADIUS =====
    radius: {
      sm: 4,
      md: 8,
      lg: 12,
      xl: 16,
      full: 9999,
    },
    
    ' ===== TYPOGRAPHY =====
    font: {
      display:    "font:ExtraLargeBoldSystemFont",  ' Hero titles
      headline:   "font:LargeBoldSystemFont",       ' Section headers
      title:      "font:MediumBoldSystemFont",      ' Card titles
      body:       "font:MediumSystemFont",          ' Descriptions
      caption:    "font:SmallSystemFont",           ' Meta, hints
      button:     "font:SmallBoldSystemFont",       ' Buttons
      micro:      "font:SmallSystemFont",           ' Tiny text
    },
    
    ' ===== FOCUS EFFECTS =====
    focus: {
      scale: 1.06,           ' 6% scale on focus
      scaleDuration: 0.15,
      glowColor: "&hFFC30060",
      borderWidth: 3,
      borderColor: "&hFFC300FF",
      shadowColor: "&hFFC30040",
      shadowBlur: 20,
      shadowOffset: "[0,8]",
      zIndexBoost: 10,
    },
    
    ' ===== ANIMATION TIMING =====
    motion: {
      fast: 0.1,
      normal: 0.2,
      slow: 0.35,
      easing: "easeOut",  ' BrightScript uses linear; this is for reference
    },
    
    ' ===== LAYOUT CONSTRAINTS =====
    layout: {
      maxWidth: 1280,
      safeMargin: 48,
      heroHeight: 380,
      posterAspect: 0.667,  ' 160:240 = 2:3
      landscapeAspect: 1.78, ' 320:180 = 16:9
      topBarHeight: 56,
    },
    
    ' ===== Z-INDEX LAYERS =====
    zIndex: {
      base: 0,
      content: 1,
      focusRing: 5,
      hero: 10,
      topBar: 50,
      modal: 100,
      toast: 200,
    }
  }
end function

' Helper: Get color with alpha
function colorAlpha(hex as integer, alpha as float) as integer
  rgb = hex and &hFFFFFF00
  a = int(alpha * 255)
  return rgb + a
end function

' Helper: Format color for XML (0xRRGGBBAA)
function colorXml(hex as integer) as string
  return "0x" + right("00000000" + hex.toStr(16), 8)
end function

' Helper: Build gradient URI for Poster (programmatic)
function heroGradientUri() as string
  return "pkg:/images/hero-gradient.png"
end function

' ===== UTILITY FUNCTIONS (from theme.brs) =====

' Converte para minusculas (BrightScript nao tem toLower em strings).
function lowerCase(text as string) as string
  upperAlpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
  lowerAlpha = "abcdefghijklmnopqrstuvwxyz"
  result = ""
  for i = 0 to text.Len() - 1
    ch = text.Mid(i, 1)
    idx = InStr(1, upperAlpha, ch)
    if idx > 0 then
      result = result + lowerAlpha.Mid(idx - 1, 1)
    else
      result = result + ch
    end if
  end for
  return result
end function

' Remove simbolos decorativos que algumas Roku exibem como quadrados vazios.
' O texto/metadado original permanece intacto no catalogo.
function cleanLiveLabel(value as string) as string
  if value = invalid then return ""
  cleaned = value
  ' Fontes podem trocar os emojis decorativos. Remover quadrados e variation
  ' selectors que algumas fontes Roku não conseguem desenhar.
  unsupported = ["⌚", "⏩", "⚽", "✅", "✊", "⭐", "■", "□", "▪", "▫", "◼", "◻", "▣", "▢", "◾", "◽", "⬛", "⬜", "🔲", "🔳", "🟥", "🟧", "🟨", "🟩", "🟦", "🟪", "🟫", "🔴", "🟠", "🟡", "🟢", "🔵", "🟣", "📺", "📡", "️", "�"]
  for each symbol in unsupported
    cleaned = cleaned.Replace(symbol, "")
  end for
  cleaned = cleaned.Replace("  ", " ").Replace("  ", " ").Replace("  ", " ")
  cleaned = cleaned.trim()
  while cleaned.Len() > 0
    first = cleaned.Left(1)
    if first = "·" or first = "|" or first = "•" or first = "-" or first = "_"
      cleaned = cleaned.Mid(1).trim()
    else
      exit while
    end if
  end while
  cleaned = cleaned.Replace(";", " · ")
  return cleaned
end function

function liveCategoryLabel(value as string) as string
  labels = {
    news: "Notícias", sports: "Esportes", sport: "Esportes", entertainment: "Entretenimento",
    movies: "Filmes", movie: "Filmes", series: "Séries", kids: "Infantil", children: "Infantil",
    music: "Música", documentary: "Documentários", documentaries: "Documentários", general: "Geral",
    religious: "Religioso", education: "Educação", lifestyle: "Estilo de vida", business: "Negócios",
    weather: "Clima", travel: "Viagens", food: "Culinária", cooking: "Culinária", auto: "Automóveis",
    shopping: "Compras", culture: "Cultura", science: "Ciência", technology: "Tecnologia",
    comedy: "Comédia", drama: "Drama", classic: "Clássicos", action: "Ação", animation: "Animação",
    family: "Família", world: "Mundo", local: "Local", regional: "Regional"
  }
  parts = []
  for each part in value.Split(";")
    label = cleanLiveLabel(part.trim())
    key = LCase(label)
    if labels.DoesExist(key) then label = labels[key]
    if label <> "" then parts.Push(label)
  end for
  if parts.Count() = 0 then return "Sem categoria"
  return parts.Join(" · ")
end function

' Garante que a URL base da API aponte para o endpoint api.php.
function apiUrl(server as string) as string
  if server = "" then return server
  s = server.trim()
  i = s.InStr("api.php")
  if i >= 0 then return s.Left(i + 7)
  if Right(s, 1) = "/" then return s + "api.php"
  return s + "/api.php"
end function

' Legacy theme() for backward compatibility
function theme() as object
  d = design()
  return {
    bg: d.bgPrimary
    text: d.textPrimary
    subtext: d.textMuted
    accent: d.accent
    mx: 96
    my: 54
  }
end function

' ---------------------------------------------------------------------------
' Codificacao de URL em UTF-8 (compartilhada por Search, Settings e Setup).
' ---------------------------------------------------------------------------
function hexDigit(value as integer) as string
  if value < 10 then return chr(48 + value)
  return chr(55 + value)
end function

function hex2(byteValue as integer) as string
  hi = int(byteValue / 16)
  return hexDigit(hi) + hexDigit(byteValue - hi * 16)
end function

' Ajusta as dimensões pedidas ao proxy de imagens (img.php) para o tamanho em que
' a imagem será exibida. O proxy faz crop "cover", então pedir o tamanho real da
' caixa evita esticamento (ex.: backdrop 16:9 numa faixa de 1280x380).
' A URL vem sempre como ".../img.php?u=<encodado>&w=NNN&h=NNN".
function fitImg(url as string, w as integer, h as integer) as string
  if url = invalid or url = "" then return ""
  p = InStr(0, url, "&w=")
  if p = 0 then return url
  return url.Left(p - 1) + "&w=" + w.toStr() + "&h=" + h.toStr()
end function

function enc(value as string) as string
  out = ""
  for i = 0 to value.len() - 1
    code = asc(value.mid(i, 1))
    if code < 128 then
      if (code >= 48 and code <= 57) or (code >= 65 and code <= 90) or (code >= 97 and code <= 122) or code = 45 or code = 95 or code = 46 then
        out = out + value.mid(i, 1)
      else
        out = out + "%" + hex2(code)
      end if
    else if code < 2048 then
      out = out + "%" + hex2(192 + int(code / 64)) + "%" + hex2(128 + (code - int(code / 64) * 64))
    else if code < 65536 then
      b1 = int(code / 4096)
      b2 = int(code / 64) - int(int(code / 64) / 64) * 64
      out = out + "%" + hex2(224 + b1) + "%" + hex2(128 + b2) + "%" + hex2(128 + (code - int(code / 64) * 64))
    else
      b1 = int(code / 262144)
      b2 = int(code / 4096) - int(int(code / 4096) / 64) * 64
      b3 = int(code / 64) - int(int(code / 64) / 64) * 64
      out = out + "%" + hex2(240 + b1) + "%" + hex2(128 + b2) + "%" + hex2(128 + b3) + "%" + hex2(128 + (code - int(code / 64) * 64))
    end if
  end for
  return out
end function
