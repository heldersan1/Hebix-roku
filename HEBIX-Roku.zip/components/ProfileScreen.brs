' Perfis locais: identidade no Registry e troca de perfil via MainScene.
sub init()
  m.scene = m.top.getScene()
  m.grid = m.top.findNode("profiles")
  m.title = m.top.findNode("title")
  m.status = m.top.findNode("status")
  m.grid.observeField("rowItemSelected", "onProfileSelected")
  m.nameDialog = invalid
  m.pendingName = ""
  m.choosingEmoji = false
  m.profileData = readProfiles()
  buildProfileGrid()
  m.top.setFocus(true)
  focusContent()
end sub

function readProfiles() as object
  section = CreateObject("roRegistrySection", "profiles")
  raw = section.Read("list")
  profiles = invalid
  if raw <> invalid and raw <> "" then profiles = ParseJson(raw)
  if profiles = invalid or profiles.Count() = 0 then
    profiles = [{id: "default", name: "Meu perfil", emoji: "🙂", preferences: {}}]
    section.Write("list", FormatJson(profiles))
    section.Flush()
  end if
  return profiles
end function

sub buildProfileGrid()
  root = CreateObject("roSGNode", "ContentNode")
  row = root.CreateChild("ContentNode")
  for each profile in m.profileData
    row.CreateChild("ContentNode").update({
      id: profile.id,
      t: profile.name,
      emoji: profile.emoji,
      isActive: profile.id = m.top.activeId,
      isCreate: false
    }, true)
  end for
  row.CreateChild("ContentNode").update({
    id: "create",
    t: "Criar perfil",
    subtitle: "Adicionar pessoa",
    emoji: "+",
    isActive: false,
    isCreate: true
  }, true)
  m.grid.content = root
  m.grid.setFocus(true)
  if m.choosingEmoji then
    m.title.text = "Escolha um emoji"
    m.status.text = "Selecione um avatar para " + m.pendingName
  else
    m.title.text = "Quem está assistindo?"
    m.status.text = "Perfil atual: " + activeProfileLabel()
  end if
end sub

function activeProfileLabel() as string
  for each profile in m.profileData
    if profile.id = m.top.activeId then return profile.emoji + "  " + profile.name
  end for
  return "selecione um perfil"
end function

sub onProfileSelected(event as object)
  focused = event.getData()
  if focused = invalid or focused.Count() < 2 then return
  row = m.grid.content.GetChild(focused[0])
  if row = invalid then return
  item = row.GetChild(focused[1])
  if item = invalid then return

  if m.choosingEmoji then
    saveProfile(item.emoji)
  else if item.isCreate = true then
    openNameKeyboard()
  else
    m.top.selected = {id: item.id, name: item.t, emoji: item.emoji}
  end if
end sub

sub openNameKeyboard()
  if m.nameDialog <> invalid then return
  dialog = CreateObject("roSGNode", "StandardKeyboardDialog")
  dialog.title = "Criar perfil"
  dialog.message = ["Digite o nome do usuário"]
  dialog.text = ""
  dialog.buttons = ["Continuar"]
  dialog.keyboardDomain = "generic"
  dialog.observeField("buttonSelected", "onNameAccepted")
  dialog.observeField("wasClosed", "onNameDialogClosed")
  m.nameDialog = dialog
  m.scene.dialog = dialog
  dialog.setFocus(true)
  if dialog.textEditBox <> invalid then dialog.textEditBox.setFocus(true)
end sub

sub onNameAccepted(event as object)
  if m.nameDialog = invalid then return
  name = m.nameDialog.text.trim()
  closeNameDialog()
  if name = "" then
    m.status.text = "Digite um nome para continuar"
    focusContent()
    return
  end if
  if name.Len() > 24 then name = name.Left(24)
  m.pendingName = name
  m.choosingEmoji = true
  buildEmojiGrid()
end sub

sub onNameDialogClosed(event as object)
  if m.nameDialog = invalid then return
  closeNameDialog()
  m.status.text = "Criação cancelada"
  focusContent()
end sub

sub closeNameDialog()
  if m.nameDialog = invalid then return
  m.scene.dialog = invalid
  m.nameDialog = invalid
end sub

sub buildEmojiGrid()
  emojis = ["🙂", "😀", "😎", "🤩", "🐼", "🐱", "🌻", "⚽"]
  root = CreateObject("roSGNode", "ContentNode")
  row = root.CreateChild("ContentNode")
  for each emoji in emojis
    row.CreateChild("ContentNode").update({
      id: "emoji_" + emoji,
      t: emoji,
      emoji: emoji,
      isActive: false,
      isCreate: false
    }, true)
  end for
  m.grid.content = root
  m.title.text = "Escolha um emoji"
  m.status.text = "Selecione um avatar para " + m.pendingName
  m.grid.setFocus(true)
end sub

sub saveProfile(emoji as string)
  dt = CreateObject("roDateTime")
  profile = {
    id: "profile_" + dt.AsSeconds().toStr() + "_" + Rnd(999999).toStr(),
    name: m.pendingName,
    emoji: emoji,
    preferences: {}
  }
  m.profileData.Push(profile)
  section = CreateObject("roRegistrySection", "profiles")
  section.Write("list", FormatJson(m.profileData))
  section.Flush()
  m.top.selected = {id: profile.id, name: profile.name, emoji: profile.emoji}
end sub

sub focusContent()
  if m.grid <> invalid and m.grid.content <> invalid and m.grid.content.GetChildCount() > 0 then
    m.grid.setFocus(true)
  else
    m.top.setFocus(true)
  end if
end sub

function onKeyEvent(key as string, press as boolean) as boolean
  if not press then return false
  if LCase(key) = "back" and m.choosingEmoji then
    m.choosingEmoji = false
    m.pendingName = ""
    buildProfileGrid()
    return true
  end if
  return false
end function
