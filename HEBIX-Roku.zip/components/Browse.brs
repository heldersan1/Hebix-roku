' Browse por categoria e paginação keyset. Usa o contrato real de ?a=list.
sub init()
  m.scene = m.top.getScene()
  m.base = origin(m.scene.server)
  m.api = m.scene.server
  m.cat = 0
  m.after = 0
  m.more = false
  m.loading = false
  m.pageSize = 30
  m.title = m.top.findNode("title")
  m.status = m.top.findNode("status")
  m.spinner = m.top.findNode("loadSpinner")
  m.cats = m.top.findNode("cats")
  m.items = m.top.findNode("items")
  m.focusedLabel = m.top.findNode("focused")
  m.focusedMeta = m.top.findNode("focusedMeta")
  m.top.observeField("focusedChild", "onFocusedChild")
  m.cats.observeField("rowItemFocused", "onCatFocused")
  m.items.observeField("rowItemFocused", "onItemFocused")
  m.items.observeField("rowItemSelected", "onItemSelected")
  ' init() roda antes de kind ser atribuido pelo MainScene.
  m.top.observeField("contentKind", "onSectionChanged")
end sub

sub onSectionChanged(ev)
  m.title.text = mediaTypeName(m.top.contentKind)
  loadCats()
end sub

function origin(url) as string
  p = InStr(0, url, "//")
  if p < 0 then return url
  p += 2
  s = InStr(p, url, "/")
  if s > 0 then return url.Left(s - 1)
  return url
end function

function absImg(path) as string
  if path = invalid or path = "" then return ""
  if path.Left(4) = "http" then return path
  return m.base + path
end function

function mediaTypeName(mediaKind) as string
  if mediaKind = 1 then return "Filmes"
  if mediaKind = 2 then return "Séries"
  return "Ao vivo"
end function

sub request(path, successName, errorName)
  t = CreateObject("roSGNode", "ApiTask")
  t.url = m.api + path
  t.observeField("result", successName)
  t.observeField("error", errorName)
  t.control = "RUN"
end sub

sub loadCats()
  m.status.text = ""
  m.spinner.visible = true
  m.spinner.control = "start"
  request("?a=cats&k=" + m.top.contentKind.toStr(), "onCatsResult", "onCatsError")
end sub

sub onCatsResult(ev)
  r = ev.getData()
  if r = invalid or r.c = invalid then
    m.spinner.control = "stop"
    m.spinner.visible = false
    m.status.text = "Nenhuma categoria encontrada"
    return
  end if
  content = CreateObject("roSGNode", "ContentNode")
  row = content.CreateChild("ContentNode")
  row.update({ id: 0, t: "Todos" }, true)
  for each cat in r.c
    row.CreateChild("ContentNode").update({ id: cat.id, t: cat.t }, true)
  end for
  m.cats.content = content
  m.cats.setFocus(true)
  loadItems(true)
end sub

sub onCatsError(ev)
  m.spinner.control = "stop"
  m.spinner.visible = false
  m.status.text = "Erro ao carregar categorias: " + ev.getData()
end sub

sub onCatFocused()
  f = m.cats.rowItemFocused
  if f = invalid or f.Count() < 2 then return
  row = m.cats.content.GetChild(f[0])
  if row = invalid then return
  item = row.GetChild(f[1])
  if item = invalid then return
  m.cat = item.id
  loadItems(true)
end sub

sub loadItems(reset)
  if reset then
    m.after = 0
    m.items.content = invalid
  end if
  if m.loading then return
  m.loading = true
  m.status.text = ""
  m.spinner.visible = true
  m.spinner.control = "start"
  params = "?a=list&kind=" + m.top.contentKind.toStr() + "&cat=" + m.cat.toStr() + "&n=" + m.pageSize.toStr()
  if m.after > 0 then params = params + "&after=" + m.after.toStr()
  request(params, "onItemsResult", "onItemsError")
end sub

sub onItemsResult(ev)
  r = ev.getData()
  m.loading = false
  m.spinner.control = "stop"
  m.spinner.visible = false
  if r = invalid or r.i = invalid then
    m.status.text = "Nenhum item encontrado"
    return
  end if
  content = m.items.content
  if content = invalid
    content = CreateObject("roSGNode", "ContentNode")
    content.CreateChild("ContentNode")
    m.items.content = content
  end if
  row = content.GetChild(0)
  for each item in r.i
    row.CreateChild("ContentNode").update({ p: fitImg(absImg(item.p), 160, 240), t: item.t, id: item.id, k: item.k, y: item.y }, true)
  end for
  m.more = r.more
  if r.next <> invalid then m.after = r.next
  suffix = ""
  if m.more then suffix = " · mais disponíveis"
  m.status.text = row.GetChildCount().toStr() + " itens" + suffix
  ' não rouba o foco das categorias enquanto o usuário navega os chips
  if not m.cats.isInFocusChain() then m.items.setFocus(true)
end sub

sub onItemsError(ev)
  m.loading = false
  m.spinner.control = "stop"
  m.spinner.visible = false
  m.status.text = "Erro ao carregar itens: " + ev.getData()
end sub

sub onItemFocused()
  f = m.items.rowItemFocused
  if f = invalid or f.Count() < 2 then return
  row = m.items.content.GetChild(f[0])
  if row = invalid then return
  item = row.GetChild(f[1])
  if item = invalid then return
  m.focusedLabel.text = item.t
  meta = ""
  if item.y > 0 then meta = item.y.toStr()
  if meta <> "" then meta = meta + "  ·  "
  m.focusedMeta.text = meta + mediaTypeName(item.k)
  if m.more and not m.loading and f[1] >= row.GetChildCount() - 1 then loadItems(false)
end sub

sub onItemSelected()
  f = m.items.rowItemFocused
  if f = invalid or f.Count() < 2 then return
  row = m.items.content.GetChild(f[0])
  if row = invalid then return
  item = row.GetChild(f[1])
  if item = invalid then return
  m.top.selected = { id: item.id, k: item.k, t: item.t }
end sub

' RowList não tem rowFocused: o índice da linha focada é rowItemFocused[0].
function navAtFirstRow(list) as boolean
  f = list.rowItemFocused
  return f <> invalid and f.Count() > 1 and f[0] = 0
end function

function onKeyEvent(key, press) as boolean
  if not press then return false
  key = LCase(key)
  if key = "up"
    if m.items.isInFocusChain() and navAtFirstRow(m.items) and m.cats.content <> invalid
      m.cats.setFocus(true)
      return true
    end if
    m.scene.callFunc("focusTopBar")
    return true
  else if key = "down" and m.cats.isInFocusChain() and m.items.content <> invalid
    m.items.setFocus(true)
    return true
  end if
  return false
end function

sub focusContent()
  if m.cats.content <> invalid and m.cats.content.GetChildCount() > 0 then
    m.cats.setFocus(true)
  else
    m.top.setFocus(true)
  end if
end sub

sub onFocusedChild()
  if m.top.isInFocusChain() and not m.cats.isInFocusChain() and not m.items.isInFocusChain() then focusContent()
end sub
