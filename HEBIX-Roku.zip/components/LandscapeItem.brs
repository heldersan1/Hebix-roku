sub init()
  m.poster = m.top.findNode("poster")
  m.title = m.top.findNode("title")
  m.focusRing = m.top.findNode("focusRing")
  m.focusBar = m.top.findNode("focusBar")
end sub

sub onItem()
  c = m.top.itemContent
  if c = invalid then return
  if c.p <> invalid then m.poster.uri = fitImg(c.p, 320, 180) else m.poster.uri = "pkg:/images/no-poster.png"
  if c.t <> invalid then m.title.text = c.t
end sub

sub onFocusChange()
  fp = 0.0
  if m.top.focusPercent <> invalid then fp = m.top.focusPercent
  ihf = false
  if m.top.itemHasFocus <> invalid then ihf = m.top.itemHasFocus
  focused = (fp > 0.5) or ihf
  m.focusBar.focusPercent = fp
  m.focusBar.focused = focused
  m.focusRing.visible = focused
  if focused then m.focusRing.opacity = fp
end sub
