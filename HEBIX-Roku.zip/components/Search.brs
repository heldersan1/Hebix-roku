' Busca unificada: três chamadas paginadas (filmes, séries e live), mescladas no cliente.
sub init()
  m.scene = m.top.getScene()
  m.base = origin(m.scene.server)
  m.api = m.scene.server
  m.status = m.top.findNode("status")
  m.results = m.top.findNode("results")
  m.debounce = m.top.findNode("debounce")
  m.debounce.observeField("fire", "onDebounce")
  m.results.observeField("rowItemSelected", "onSelected")
  m.results.observeField("rowItemFocused", "onFocused")
  m.newSearch = m.top.findNode("newSearch")
  m.newSearchGlow = m.top.findNode("newSearchGlow")
  m.top.observeField("focusedChild", "onFocusChanged")
  m.query = ""
  m.generation = 0
  m.dialog = invalid
  m.nextByKind = {}
  m.moreByKind = {}
  m.loadingByKind = {}
  m.searchFocusAfterResults = false
end sub

sub onFocusChanged()
  focused = m.newSearch.isInFocusChain()
  if focused then m.newSearchGlow.focusPercent = 1.0 else m.newSearchGlow.focusPercent = 0.0
  m.newSearchGlow.focused = focused
end sub

sub openInitialKeyboard()
  if m.dialog = invalid and m.query = "" then openKeyboard()
end sub

function origin(url) as string
  p = InStr(0, url, "//")
  if p < 0 then return url
  p += 2
  s = InStr(p, url, "/")
  if s > 0 then return url.Left(s - 1)
  return url
end function

function absImg(path) as string
  if path = invalid or path = "" then return ""
  if path.Left(4) = "http" then return path
  return m.base + path
end function

sub openKeyboard()
  d = CreateObject("roSGNode", "StandardKeyboardDialog")
  d.title = "Buscar"
  d.text = m.query
  d.buttons = ["Buscar"]
  d.keyboardDomain = "generic"
  d.observeField("buttonSelected", "onSearch")
  d.observeField("wasClosed", "onClosed")
  m.scene.dialog = d
  m.dialog = d
  ' Sem foco explícito o TextEditBox interno do teclado não recebe os caracteres.
  m.dialog.setFocus(true)
  ' Doc Keyboard: "The Keyboard node must have the key focus in order to work properly."
  if m.dialog.textEditBox <> invalid then m.dialog.textEditBox.setFocus(true)
end sub

sub onSearch(ev)
  if m.dialog = invalid then return
  value = m.dialog.text.trim()
  print "[nav] search submit len=" + value.Len().toStr()
  m.scene.dialog = invalid
  m.dialog = invalid
  startSearch(value)
  m.newSearch.setFocus(true)
end sub

sub onClosed(ev)
  ' Back fecha o teclado e cancela. Só o botão "Buscar" inicia a busca.
  if m.dialog = invalid then return
  m.scene.dialog = invalid
  m.dialog = invalid
  m.status.text = "Busca cancelada"
  focusContent()
end sub

sub startSearch(value)
  m.query = value
  m.generation = m.generation + 1
  m.loadingByKind = {}
  m.nextByKind = {}
  m.moreByKind = {}
  m.searchFocusAfterResults = true
  m.results.content = invalid
  m.status.text = "Buscando..."
  m.debounce.control = "start"
end sub

sub onDebounce()
  print "[nav] search debounce len=" + m.query.Len().toStr()
  if m.query = "" then
    m.status.text = "Digite um termo para buscar"
    m.results.content = invalid
    return
  end if
  m.nextByKind = {}
  m.moreByKind = {}
  loadMedia(1)
  loadMedia(2)
  loadMedia(0)
end sub

sub loadMedia(mediaKind)
  ' Chaves de associative array devem ser string (roAssociativeArray exige String).
  key = mediaKind.toStr()
  ' Chave ausente devolve Invalid: comparar com true evita "Invalid used in IF-clause".
  if m.loadingByKind[key] = true then return
  m.loadingByKind[key] = true
  action = "search"
  if mediaKind = 0 then action = "live_search"
  url = m.api + "?a=" + action + "&q=" + enc(m.query) + "&kind=" + key + "&n=30&g=" + m.generation.toStr()
  ' Diagnóstico sem expor o termo: apenas tipo e tamanho.
  after = m.nextByKind[key]
  if after <> invalid and after > 0 then url = url + "&after=" + after.toStr()
  t = CreateObject("roSGNode", "ApiTask")
  t.url = url
  t.observeField("result", "onKindResult")
  t.observeField("error", "onKindError")
  t.control = "RUN"
end sub

sub onKindResult(ev)
  r = ev.getData()
  node = ev.getRoSGNode()
  mediaKind = mediaKindFromUrl(node.url)
  generation = generationFromUrl(node.url)
  if generation <> m.generation then return
  m.loadingByKind[mediaKind.toStr()] = false
  if r = invalid then return
  if mediaKind = 0 and r.items <> invalid
    liveItems = []
    for each live in r.items
      liveItems.push({id: live.id, k: 0, t: live.name, y: 0, p: live.logo})
    end for
    r.i = liveItems
  end if
  if r.i = invalid then return
  m.moreByKind[mediaKind.toStr()] = r.more
  if r.next <> invalid then m.nextByKind[mediaKind.toStr()] = r.next
  content = m.results.content
  if content = invalid
    content = CreateObject("roSGNode", "ContentNode")
    content.CreateChild("ContentNode")
    m.results.content = content
  end if
  row = content.GetChild(0)
  for each item in r.i
    row.CreateChild("ContentNode").update({ p: absImg(item.p), t: item.t, type: mediaTypeName(item.k), id: item.id, k: item.k, y: item.y }, true)
  end for
  m.status.text = row.GetChildCount().toStr() + " resultados"
  ' Deixa Nova busca pronta para OK; Down leva de volta à grade de resultados.
  if m.searchFocusAfterResults and m.top.isInFocusChain()
    m.searchFocusAfterResults = false
    m.newSearch.setFocus(true)
  end if
end sub

sub onKindError(ev)
  node = ev.getRoSGNode()
  if generationFromUrl(node.url) <> m.generation then return
  m.loadingByKind[mediaKindFromUrl(node.url).toStr()] = false
  m.status.text = "Erro na busca: " + ev.getData()
end sub

function generationFromUrl(url) as integer
  p = url.instr("g=")
  if p = 0 then return -1
  value = url.mid(p + 2).tokenize("&")[0]
  return value.toInt()
end function
function mediaTypeName(mediaKind) as string
  if mediaKind = 1 then return "Filme"
  if mediaKind = 2 then return "Série"
  return "Ao vivo"
end function
function mediaKindFromUrl(url) as integer
  p = url.instr("kind=")
  if p = 0 then return -1
  value = url.mid(p + 5).tokenize("&")[0]
  return value.toInt()
end function

sub loadMore(mediaKind)
  if m.moreByKind[mediaKind.toStr()] <> true then return
  loadMedia(mediaKind)
end sub

sub onFocused()
  f = m.results.rowItemFocused
  if f = invalid or f.Count() < 2 then return
  row = m.results.content.GetChild(f[0])
  if row = invalid then return
  if f[1] < row.GetChildCount() - 1 then return
  loadMore(1)
  loadMore(2)
  loadMore(0)
end sub

sub onSelected()
  f = m.results.rowItemFocused
  if f = invalid or f.Count() < 2 then return
  row = m.results.content.GetChild(f[0])
  if row = invalid then return
  item = row.GetChild(f[1])
  if item = invalid then return
  m.top.selected = { id: item.id, k: item.k, t: item.t }
end sub

function onKeyEvent(key, press) as boolean
  if not press then return false
  key = LCase(key)
  if key = "back" and m.query = "" then return false
  if key = "ok" and m.newSearch.hasFocus() then
    onNewSearch()
    return true
  else if key = "down" and m.newSearch.isInFocusChain()
    if m.results.content <> invalid and m.results.content.GetChildCount() > 0
      m.results.setFocus(true)
      return true
    end if
  end if
  if key = "up" then
    if m.results.isInFocusChain() then
      m.newSearch.setFocus(true)
      return true
    end if
    m.scene.callFunc("focusTopBar")
    return true
  end if
  return false
end function

sub focusContent()
  content = m.results.content
  if content <> invalid and content.GetChildCount() > 0
    row = content.GetChild(0)
    if row <> invalid and row.GetChildCount() > 0
      m.results.setFocus(true)
      return
    end if
  end if
  m.newSearch.setFocus(true)
end sub

sub onNewSearch()
  openKeyboard()
end sub
