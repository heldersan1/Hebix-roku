' Pareamento pelo celular: mostra o QR, espera o envio e ativa a lista.
sub init()
  m.top.observeField("focusedChild", "onFocusedChild")
  m.qr = m.top.findNode("qr")
  m.link = m.top.findNode("link")
  m.status = m.top.findNode("status")
  m.poll = m.top.findNode("poll")
  m.poll.observeField("fire", "onPoll")
  m.code = ""
  m.done = false
  m.scene = m.top.getScene()
  m.api = m.scene.server
  m.qr.uri = ""
  m.poll.control = "stop"
  m.pending = false
  m.pollPending = false
  newCode()
end sub

sub focusContent()
  m.top.setFocus(true)
end sub

sub onScreenHidden()
  m.done = true
  m.poll.control = "stop"
end sub

sub onFocusedChild()
end sub

sub request(path as string, ok as string, fail as string)
  t = CreateObject("roSGNode", "ApiTask")
  t.observeField("result", ok)
  t.observeField("error", fail)
  t.url = m.api + path
  t.control = "RUN"
end sub

sub newCode()
  if m.pending then return
  m.pending = true
  m.code = ""
  m.done = false
  m.status.text = "Gerando código..."
  m.status.color = "0xFFC300FF"
  request("?a=pair_new", "onNew", "onFail")
end sub

sub onNew(ev)
  r = ev.GetData()
  if r = invalid or r.code = invalid then
    m.pending = false
    m.status.text = "Sem conexão com o servidor. Tente de novo."
    return
  end if
  m.code = r.code
  m.pending = false
  m.qr.uri = r.qr
  m.link.text = r.link
  m.status.text = "Aguardando o celular..."
  m.status.color = "0xFFC300FF"
  m.poll.control = "start"
end sub

sub onPoll()
  if m.done or m.code = "" or m.pollPending then return
  m.pollPending = true
  request("?a=pair_status&code=" + m.code, "onPollStatus", "onPollFail")
end sub

sub onPollStatus(ev)
  m.pollPending = false
  r = ev.GetData()
  if r = invalid or r.found = invalid or r.found = 0 then return
  if r.paired = 1 and r.source > 0 then
    m.done = true
    m.poll.control = "stop"
    m.status.text = "Lista recebida! Ativando..."
    m.status.color = "0x46D369FF"
    m.sourceId = r.source
    post("?a=source_activate", "id=" + r.source.toStr(), "onActivated", "onActivateFail")
  end if
end sub

sub onPollFail(ev)
  m.pollPending = false
  onFail(ev)
end sub

sub onActivated(ev)
  m.status.text = "Lista ativa. Baixando o catálogo..."
  post("?a=source_sync", "id=" + m.sourceId.toStr(), "onSynced", "onSyncFail")
end sub

sub onSynced(ev)
  r = ev.GetData()
  if r = invalid or r.ok <> 1 then
    onSyncFail(ev)
    return
  end if
  m.poll.control = "stop"
  m.status.text = "Tudo pronto! Abra a home para ver a lista."
  m.status.color = "0x46D369FF"
  m.scene.callFunc("pairDone")
end sub

sub onActivateFail(ev)
  m.poll.control = "stop"
  m.status.text = "Lista recebida, mas não foi possível ativá-la. Tente em Ajustes."
  m.status.color = "0xF44336FF"
end sub

sub onSyncFail(ev)
  m.poll.control = "stop"
  m.status.text = "Lista ativa, mas a sincronização falhou. Tente Atualizar em Ajustes."
  m.status.color = "0xF44336FF"
end sub

sub post(path as string, body as string, ok as string, fail as string)
  t = CreateObject("roSGNode", "ApiTask")
  t.observeField("result", ok)
  t.observeField("error", fail)
  t.url = m.api + path
  t.postData = body
  t.control = "RUN"
end sub

sub onFail(ev)
  if m.done then return
  m.status.text = "Não consegui falar com o servidor. Verifique a rede."
end sub

sub onKeyEvent(key as string, press as boolean) as boolean
  if not press then return false
  if key = "back" then
    m.poll.control = "stop"
    return false
  end if
  return false
end sub
