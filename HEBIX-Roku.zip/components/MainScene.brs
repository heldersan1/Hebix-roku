' Screen stack + theme; inactive tab screens are capped to limit retained posters and content.
sub init()
  m.tabs = m.top.findNode("tabs")
  m.prebufferHolder = m.top.findNode("prebufferHolder")
  m.stack = m.top.findNode("stack")
  m.tabScreens = {}
  m.tabUseOrder = []
  m.tabNodeOrder = []
  m.currentTab = invalid
  m.currentTabName = ""
  m.topBar = m.top.findNode("topBar")
  m.backHint = m.top.findNode("backHint")
  m.topBar.observeField("activated", "onTabActivated")
  m.menuMode = false
  savedServer = regRead("server")
  if InStr(1, savedServer, "192.168.1.246") > 0
    ' This address was the PC-hosted backend; move existing installs to Fly.io.
    savedServer = "https://hebix.fly.dev/api.php"
    sec = CreateObject("roRegistrySection", "setup")
    sec.Write("server", savedServer)
    sec.Flush()
  end if
  m.top.server = apiUrl(savedServer)
  m.top.profileId = activeProfileId()

  if m.top.server = ""
    pushSetup()
  else
    showTab("home")
  end if

end sub

function activeProfileId() as string
  section = CreateObject("roRegistrySection", "profiles")
  id = section.Read("activeId")
  if id = invalid or id = "" then
    id = "default"
    section.Write("activeId", id)
    section.Flush()
  end if
  return id
end function

function regRead(key) as string
  sec = CreateObject("roRegistrySection", "setup")
  v = sec.Read(key)
  if v = invalid then v = ""
  return v
end function

sub push(node)
  m.stack.appendChild(node)
  node.callFunc("focusContent")
  m.current = node
  if node.subtype() = "Setup"
    node.observeField("done", "onSetupDone")
  else if node.subtype() = "HomeScreen"
    node.observeField("selected", "onHomeSelected")
  end if
  syncChrome()
end sub

sub pop()
  if m.stack.getChildCount() > 0
    removeStackChild(m.stack.getChildCount() - 1)
    if m.stack.getChildCount() > 0
      m.current = m.stack.getChild(m.stack.getChildCount() - 1)
    else
      m.current = m.currentTab
    end if
    if m.current <> invalid then m.current.callFunc("focusContent")
    syncChrome()
  end if
end sub

sub removeStackChild(index as integer)
  child = m.stack.getChild(index)
  if child <> invalid and child.subtype() = "Details" then child.callFunc("onScreenHidden")
  if child <> invalid and child.subtype() = "Player" then child.callFunc("stopPlayback")
  if child <> invalid and child.subtype() = "LiveScreen" then child.callFunc("onScreenHidden")
  if child <> invalid and child.subtype() = "Pair" then child.callFunc("onScreenHidden")
  if child <> invalid and child.subtype() = "Player" and child.item <> invalid and child.item.live = true
    setLivePlaybackState("idle")
  end if
  m.stack.removeChildIndex(index)
end sub

' A TopBar não deve aparecer sobre o vídeo em reprodução.
sub syncChrome()
  show = true
  if m.current <> invalid then
    if m.current.subtype() = "Player" then show = false
  end if
  m.topBar.visible = show
  m.backHint.visible = m.stack.getChildCount() = 0
end sub
sub onHomeSelected(ev)
  item = ev.getData()
  if item <> invalid then openDetails(item)
end sub

sub onBrowseSelected(ev)
  item = ev.getData()
  if item = invalid then return
  if item.live = true
    playLive(item)
    return
  end if
  openDetails(item)
end sub

sub onSearchSelected(ev)
  item = ev.getData()
  if item = invalid then return
  openDetails(item)
end sub

sub openLiveItem(id, kind, title)
  details = CreateObject("roSGNode", "Details")
  details.contentKind = kind
  details.itemId = id
  details.observeField("play", "onPlay")
  details.observeField("favoriteChanged", "onFavoriteChanged")
  if m.current <> invalid then m.current.setFocus(false)
  m.stack.appendChild(details)
  details.callFunc("focusContent")
  m.current = details
  syncChrome()
end sub

sub openDetails(item)
  releasePrebuffer()
  details = CreateObject("roSGNode", "Details")
  details.contentKind = item.k
  details.itemId = item.id
  details.observeField("play", "onPlay")
  details.observeField("favoriteChanged", "onFavoriteChanged")
  details.observeField("prebuffer", "onPrebufferRequested")
  if m.current <> invalid then m.current.setFocus(false)
  m.stack.appendChild(details)
  details.callFunc("focusContent")
  m.current = details
  syncChrome()
end sub

sub onFavoriteChanged(event as object)
  refreshHome()
  if m.tabScreens.DoesExist("favorites")
    screen = m.tabScreens["favorites"]
    screen.reload = screen.reload + 1
  end if
end sub

sub refreshHome()
  if m.tabScreens.DoesExist("home") then
    home = m.tabScreens["home"]
    home.reload = home.reload + 1
  end if
end sub

sub openPlayerItem(id, kind, ext)
  item = {id:id,k:kind,ext:ext}
  player = invalid
  if m.prebufferPlayer <> invalid and m.prebufferItem <> invalid and m.prebufferItem.id = id and m.prebufferItem.k = kind
    player = m.prebufferPlayer
    m.prebufferHolder.removeChild(player)
    m.prebufferPlayer = invalid
    m.prebufferItem = invalid
  else
    releasePrebuffer()
    player = CreateObject("roSGNode", "Player")
  end if
  m.stack.appendChild(player)
  player.item = item
  player.callFunc("focusContent")
  m.current = player
  syncChrome()
end sub

sub onLiveSelected(ev)
  item = ev.getData()
  playLive(item)
end sub

sub playLive(item)
  if item = invalid or item.u = invalid or item.u = "" then return
  player = CreateObject("roSGNode", "Player")
  player.item = item
  player.observeField("playbackState", "onPlaybackState")
  m.stack.appendChild(player)
  player.callFunc("focusContent")
  m.current = player
  syncChrome()
end sub

sub onPlaybackState(ev)
  item = ev.getData()
  if item <> invalid then setLivePlaybackState(item)
end sub

sub setLivePlaybackState(state as string)
  if m.tabScreens.DoesExist("live")
    m.tabScreens["live"].callFunc("setPlaybackState", state)
  end if
end sub

sub onPlay(ev)
  item = ev.getData()
  if item = invalid or not item.DoesExist("id") or not item.DoesExist("k") then return
  openPlayerItem(item.id, item.k, item.ext)
end sub

sub onPrebufferRequested(event as object)
  item = event.getData()
  if item = invalid or (item.DoesExist("cancel") and item.cancel = true)
    releasePrebuffer()
    return
  end if
  if item.u = invalid or item.u = "" then return
  if m.prebufferItem <> invalid and m.prebufferItem.id = item.id and m.prebufferItem.k = item.k then return
  releasePrebuffer()
  player = CreateObject("roSGNode", "Player")
  m.prebufferHolder.appendChild(player)
  m.prebufferPlayer = player
  m.prebufferItem = item
  if not player.callFunc("preparePlayback", item)
    releasePrebuffer()
  end if
end sub

sub cancelPrebuffer()
  releasePrebuffer()
end sub

sub releasePrebuffer()
  if m.prebufferPlayer <> invalid
    m.prebufferPlayer.callFunc("stopPlayback")
    m.prebufferHolder.removeChild(m.prebufferPlayer)
    m.prebufferPlayer = invalid
    m.prebufferItem = invalid
  end if
end sub

sub focusTopBar()
  m.menuMode = true
  if m.current <> invalid then m.current.setFocus(false)
  m.topBar.callFunc("focusMenu")
end sub

sub onTabActivated(ev)
  index = ev.getData()
  if index = -2
    m.menuMode = false
    m.topBar.callFunc("unfocusMenu")
    if m.current <> invalid then m.current.callFunc("focusContent")
    return
  end if
  if index < 0 then return
  m.menuMode = false
  labels = ["home", "movie", "series", "live", "search", "favorites", "settings", "profile"]
  if index > labels.Count() - 1 then return
  showTab(labels[index])
end sub

sub showTab(section)
  ' Fecha detalhes/player antes de mostrar a aba selecionada.
  for i = m.stack.getChildCount() - 1 to 0 step -1
    removeStackChild(i)
  end for
  if m.current <> invalid then m.current.setFocus(false)
  if m.currentTab <> invalid
    if m.currentTab.subtype() = "HomeScreen" then m.currentTab.callFunc("onScreenHidden")
    m.currentTab.visible = false
  end if

  hadScreen = m.tabScreens.DoesExist(section)
  screen = m.tabScreens[section]
  if screen = invalid then
    if section = "home"
      screen = CreateObject("roSGNode", "HomeScreen")
      screen.observeField("selected", "onHomeSelected")
    else if section = "settings"
      screen = CreateObject("roSGNode", "Settings")
      screen.observeField("changed", "onSettingsChanged")
    else if section = "profile"
      screen = CreateObject("roSGNode", "ProfileScreen")
      screen.activeId = m.top.profileId
      screen.observeField("selected", "onProfileSelected")
    else if section = "live"
      screen = CreateObject("roSGNode", "LiveScreen")
      screen.observeField("selected", "onLiveSelected")
    else if section = "search"
      screen = CreateObject("roSGNode", "Search")
      screen.observeField("selected", "onSearchSelected")
    else if section = "favorites"
      screen = CreateObject("roSGNode", "FavoriteScreen")
      screen.observeField("selected", "onBrowseSelected")
    else
      sectionKind = 1
      if section = "series" then sectionKind = 2
      screen = CreateObject("roSGNode", "Browse")
      screen.contentKind = sectionKind
      screen.observeField("selected", "onBrowseSelected")
    end if
    screen.visible = false
    m.tabs.appendChild(screen)
    m.tabNodeOrder.push(section)
    m.tabScreens[section] = screen
  end if

  m.currentTab = screen
  m.currentTabName = section
  m.current = screen
  m.currentTab.visible = true
  m.topBar.callFunc("unfocusMenu")
  if m.currentTab.subtype() = "HomeScreen" then m.currentTab.callFunc("onScreenShown")
  if section = "live" and hadScreen then m.currentTab.callFunc("reloadCatalog")
  if section = "favorites" and hadScreen then m.currentTab.reload = m.currentTab.reload + 1
  if section = "home" and hadScreen
    m.currentTab.reload = m.currentTab.reload + 1
  end if
  labels = ["home", "movie", "series", "live", "search", "favorites", "settings", "profile"]
  for i = 0 to labels.Count() - 1
    if labels[i] = section then m.topBar.index = i
  end for
  m.currentTab.callFunc("focusContent")
  if section = "search" and not hadScreen then m.currentTab.callFunc("openInitialKeyboard")
  rememberTab(section)
  syncChrome()
end sub

sub rememberTab(section as string)
  nextOrder = []
  for each name in m.tabUseOrder
    if name <> section then nextOrder.push(name)
  end for
  nextOrder.push(section)
  m.tabUseOrder = nextOrder
  while m.tabUseOrder.Count() > 3
    oldName = m.tabUseOrder[0]
    oldScreen = m.tabScreens[oldName]
    if oldScreen <> invalid
      if oldScreen.subtype() = "HomeScreen" then oldScreen.callFunc("onScreenHidden")
      if oldScreen.subtype() = "LiveScreen" then oldScreen.callFunc("onScreenHidden")
      for i = 0 to m.tabNodeOrder.Count() - 1
        if m.tabNodeOrder[i] = oldName
          m.tabs.removeChildIndex(i)
          m.tabNodeOrder.Delete(i)
          exit for
        end if
      end for
      m.tabScreens.Delete(oldName)
    end if
    m.tabUseOrder.Delete(0)
  end while
end sub

sub onProfileSelected(event as object)
  profile = event.getData()
  if profile = invalid or profile.id = invalid or profile.id = "" then return
  m.top.profileId = profile.id
  section = CreateObject("roRegistrySection", "profiles")
  section.Write("activeId", profile.id)
  section.Flush()

  if m.tabScreens.DoesExist("profile") then m.tabScreens["profile"].activeId = profile.id
  showTab("home")
  refreshHome()
end sub

sub openPair()
  pair = CreateObject("roSGNode", "Pair")
  m.stack.appendChild(pair)
  pair.callFunc("focusContent")
  m.current = pair
  syncChrome()
end sub

sub pairDone()
  if m.current <> invalid and m.current.subtype() = "Pair" then
    pop()
    if m.current <> invalid then m.current.callFunc("focusContent")
  end if
end sub

sub pushSetup()
  s = CreateObject("roSGNode", "Setup")
  push(s)
end sub

sub openSetup()
  pushSetup()
end sub

sub onSettingsChanged(ev)
  ' A tela permanece aberta para mostrar a fonte ativa; Home é recriado ao voltar.
end sub

sub onSetupDone(ev)
  if not ev.getData() then return
  for i = m.stack.getChildCount() - 1 to 0 step -1
    if m.stack.getChild(i).subtype() = "Setup" then removeStackChild(i)
  end for
  m.current = invalid
  showTab("home")
end sub

function onKeyEvent(key, press) as boolean
  if not press then return false
  key = LCase(key)
  ' O modo menu e derivado do foco real (nao de um flag que pode ficar velho).
  if m.topBar.isInFocusChain() then
    if key = "down" or key = "back" then
      m.menuMode = false
      m.topBar.callFunc("unfocusMenu")
      if m.current <> invalid then m.current.callFunc("focusContent")
      return true
    end if
    return false
  end if
  if key = "back" and m.stack.getChildCount() > 0
    pop()
    return true
  end if
  if key = "back" and m.currentTab <> invalid
    focusTopBar()
    return true
  end if
  return false
end function
