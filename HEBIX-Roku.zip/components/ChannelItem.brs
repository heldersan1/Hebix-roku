sub init()
  m.visual = m.top.findNode("visual")
  m.logo = m.top.findNode("logo")
  m.title = m.top.findNode("title")
  m.info = m.top.findNode("info")
  m.artworkWash = m.top.findNode("artworkWash")
  m.accentStripe = m.top.findNode("accentStripe")
  m.logoPlate = m.top.findNode("logoPlate")
  m.liveBadge = m.top.findNode("liveBadge")
  m.liveDot = m.top.findNode("liveDot")
  m.focusBackground = m.top.findNode("focusBackground")
  m.focusBar = m.top.findNode("focusBar")
  m.borders = [m.top.findNode("borderTop"), m.top.findNode("borderBottom"), m.top.findNode("borderLeft"), m.top.findNode("borderRight")]
end sub

sub onItemContentChanged()
  item = m.top.itemContent
  if item = invalid then return

  if item.p <> invalid and item.p <> "" then
    m.logo.uri = item.p
  else
    m.logo.uri = "pkg:/images/no-poster.png"
  end if
  if item.t <> invalid then m.title.text = item.t
  accent = categoryAccent(item.category)
  m.accentStripe.color = accent
  m.artworkWash.color = accent
  m.logoPlate.color = "0xFFFFFF1A"
  m.liveBadge.color = "0xFFC300FF"
  m.liveDot.color = "0x141414FF"

  info = ""
  if item.category <> invalid and item.category <> "" then
    info = item.category
  else if item.info <> invalid and item.info <> "" then
    info = item.info
  else if item.y <> invalid and item.y > 0 then
    info = item.y.toStr()
  end if
  m.info.text = info
end sub

function categoryAccent(category) as string
  value = ""
  if category <> invalid then value = LCase(category.toStr())
  if InStr(0, value, "esport") >= 0 or InStr(0, value, "futebol") >= 0 then return "0x35C98AFF"
  if InStr(0, value, "notícia") >= 0 or InStr(0, value, "jornal") >= 0 or InStr(0, value, "news") >= 0 then return "0x56A7FFFF"
  if InStr(0, value, "infantil") >= 0 or InStr(0, value, "kids") >= 0 then return "0xFF7096FF"
  if InStr(0, value, "música") >= 0 or InStr(0, value, "music") >= 0 then return "0xA987FFFF"
  return "0xFFC300FF"
end function

sub onFocusChanged()
  percent = m.top.focusPercent
  if percent = invalid then percent = 0.0
  if m.top.itemHasFocus then percent = 1.0

  focused = percent > 0.0
  m.focusBar.focusPercent = percent
  m.focusBar.focused = focused
  m.focusBackground.color = "0x2A2A2AFF"
  m.focusBackground.visible = focused
  m.focusBackground.opacity = percent
  for each border in m.borders
    border.visible = focused
    border.color = "0xFFFFFFFF"
  end for

  m.title.color = "0xFFFFFFFF"
  m.info.color = "0xB3B3B3FF"
end sub
