' Home row item: alterna entre cartao (poster 160x240) e faixa (320x180)
' conforme itemContent.kind = "landscape" | "poster".
sub init()
  m.pPoster = m.top.findNode("pPoster")
  m.pTitle = m.top.findNode("pTitle")
  m.pTitleBg = m.top.findNode("pTitleBg")
  m.pFocusRing = m.top.findNode("focusRing")
  m.lPoster = m.top.findNode("lPoster")
  m.lTitle = m.top.findNode("lTitle")
  m.lFocusRing = m.top.findNode("lFocusRing")
  m.channelLogo = m.top.findNode("channelLogo")
  m.channelTitle = m.top.findNode("channelTitle")
  m.channelFocusRing = m.top.findNode("channelFocusRing")
  m.pFocusBar = m.top.findNode("pFocusBar")
  m.lFocusBar = m.top.findNode("lFocusBar")
  m.channelFocusBar = m.top.findNode("channelFocusBar")
  m.pPoster.observeField("loadStatus", "onPosterStatus")
  m.top.observeField("focusedChild", "onFocusChange")
end sub

sub onItem()
  c = m.top.itemContent
  if c = invalid then return
  m.format = ""
  if c.kind <> invalid then m.format = c.kind.toStr()
  isLand = (m.format = "landscape")
  isChannel = (m.format = "channel")
  m.top.findNode("posterGroup").visible = not isLand and not isChannel
  m.top.findNode("landGroup").visible = isLand
  m.top.findNode("channelGroup").visible = isChannel
  m.pPoster.visible = not isLand and not isChannel
  m.lPoster.visible = isLand
  m.channelLogo.visible = isChannel
  if isChannel
    if c.p <> invalid then m.channelLogo.uri = fitImg(c.p, 320, 136) else m.channelLogo.uri = "pkg:/images/no-poster.png"
    if c.t <> invalid then m.channelTitle.text = c.t
  else if isLand
    if c.p <> invalid then m.lPoster.uri = fitImg(c.p, 320, 180) else m.lPoster.uri = "pkg:/images/no-poster.png"
    if c.t <> invalid then m.lTitle.text = c.t
    m.lTitle.visible = true
  else
    if c.p <> invalid then m.pPoster.uri = fitImg(c.p, 160, 240) else m.pPoster.uri = "pkg:/images/no-poster.png"
    if c.t <> invalid then m.pTitle.text = c.t
    m.pTitle.visible = true
    m.pTitleBg.visible = true
  end if
  onFocusChange()
end sub

sub onPosterStatus()
  if m.format <> "landscape"
    m.pTitle.visible = true
    m.pTitleBg.visible = true
  end if
end sub

sub onFocusChange()
  fp = 0.0
  if m.top.focusPercent <> invalid then fp = m.top.focusPercent
  ihf = false
  if m.top.itemHasFocus <> invalid then ihf = m.top.itemHasFocus
  focused = (fp > 0.5) or ihf
  m.pFocusBar.focusPercent = fp
  m.pFocusBar.focused = focused
  m.lFocusBar.focusPercent = fp
  m.lFocusBar.focused = focused
  m.channelFocusBar.focusPercent = fp
  m.channelFocusBar.focused = focused
  if m.format = "channel"
    m.channelFocusRing.visible = focused
    if focused then m.channelFocusRing.opacity = fp
  else if m.format = "landscape"
    m.lFocusRing.visible = focused
    if focused then m.lFocusRing.opacity = fp
    m.lTitle.visible = focused
  else
    m.pFocusRing.visible = focused
    if focused then m.pFocusRing.opacity = fp
    m.pTitle.visible = true
    m.pTitleBg.visible = true
  end if
end sub
