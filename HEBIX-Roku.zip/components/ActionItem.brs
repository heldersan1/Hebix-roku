sub init()
  m.focusRing = m.top.findNode("focusRing")
  m.bg = m.top.findNode("bg")
  m.focusBar = m.top.findNode("focusBar")
end sub

sub onItem()
  c = m.top.itemContent
  if c = invalid then return
  m.top.findNode("label").text = c.t
  if c.i <> invalid then m.top.findNode("icon").uri = c.i
end sub

sub onFocusChange()
  fp = 0.0
  if m.top.focusPercent <> invalid then fp = m.top.focusPercent
  ihf = false
  if m.top.itemHasFocus <> invalid then ihf = m.top.itemHasFocus
  focused = (fp > 0.5) or ihf
  m.focusBar.focusPercent = fp
  m.focusBar.focused = focused
  m.focusRing.visible = focused
  if focused then
    m.focusRing.opacity = fp
    m.bg.color = design().bgTertiary
  else
    m.bg.color = design().bgSecondary
  end if
end sub
