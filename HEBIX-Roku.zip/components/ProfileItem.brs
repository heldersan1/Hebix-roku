sub init()
  m.focusRing = m.top.findNode("focusRing")
  m.avatar = m.top.findNode("emoji")
  m.name = m.top.findNode("name")
  m.state = m.top.findNode("state")
  m.focusBar = m.top.findNode("focusBar")
end sub

sub onItem()
  item = m.top.itemContent
  if item = invalid then return
  m.avatar.text = item.emoji
  m.name.text = item.t
  if item.isCreate = true then
    m.avatar.color = "0xFFC300FF"
    m.state.color = "0xB3B3B3FF"
    m.state.text = "Adicionar pessoa"
  else
    m.avatar.color = "0xFFFFFFFF"
    if item.isActive = true then
      m.state.color = "0xFFC300FF"
      m.state.text = "PERFIL ATUAL"
    else
      m.state.color = "0xB3B3B3FF"
      m.state.text = "Selecionar"
    end if
  end if
  onFocusChange()
end sub

sub onFocusChange()
  focused = false
  if m.top.itemHasFocus <> invalid then focused = m.top.itemHasFocus
  percent = 0.0
  if m.top.focusPercent <> invalid then percent = m.top.focusPercent
  if percent > 0.5 then focused = true
  m.focusBar.focusPercent = percent
  m.focusBar.focused = focused
  m.focusRing.visible = focused
  if focused then m.focusRing.opacity = percent
end sub
