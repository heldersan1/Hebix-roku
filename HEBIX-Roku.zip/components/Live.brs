' TV ao vivo: lista de canais à esquerda e prévia do programa à direita.
sub init()
  m.scene=m.top.getScene() : m.base=origin(m.scene.server) : m.api=m.scene.server
  m.status=m.top.findNode("status") : m.cats=m.top.findNode("cats") : m.items=m.top.findNode("items")
  m.pvTitle=m.top.findNode("pvTitle") : m.pvLogo=m.top.findNode("pvLogo")
  m.pvNow=m.top.findNode("pvNow") : m.pvNowDesc=m.top.findNode("pvNowDesc") : m.pvNext=m.top.findNode("pvNext")
  m.pvPlay=m.top.findNode("pvPlay")
  m.cats.observeField("rowItemFocused","onCatFocused")
  m.items.observeField("itemFocused","onItemFocused")
  m.items.observeField("itemSelected","onSelected")
  m.pvPlay.observeField("buttonSelected","onPlaySelected")
  m.top.observeField("focusedChild","onFocusedChild")
  m.cat=0 : m.after=0 : m.more=false : m.loading=false : m.pageSize=30 : m.count=0
  loadCats()
end sub

function origin(url) as string
  p=InStr(0,url,"//")
  if p<0 then return url
  p+=2 : s=InStr(p,url,"/")
  if s>0 then return url.Left(s-1)
  return url
end function

function absImg(path) as string
  if path=invalid or path="" then return ""
  if path.Left(4)="http" then return path
  return m.base+path
end function

sub request(path,okName,errName)
  t=CreateObject("roSGNode","ApiTask") : t.url=m.api+path : t.observeField("result",okName) : t.observeField("error",errName) : t.control="RUN"
end sub

sub loadCats()
  m.status.text="Carregando categorias..." : request("?a=cats&k=0","onCats","onError")
end sub

sub onCats(ev)
  r=ev.getData()
  if r=invalid or r.c=invalid then
    m.status.text="Nenhuma categoria encontrada" : return
  end if
  content=CreateObject("roSGNode","ContentNode")
  row=content.CreateChild("ContentNode")
  row.CreateChild("ContentNode").update({id:0,t:"Todos"},true)
  for each cat in r.c
    row.CreateChild("ContentNode").update({id:cat.id,t:cat.t},true)
  end for
  m.cats.content=content : m.cats.setFocus(true) : loadItems(true)
end sub

sub onCatFocused()
  f=m.cats.rowItemFocused
  if f=invalid or f.Count()<2 then return
  row=m.cats.content.GetChild(f[0])
  if row=invalid then return
  item=row.GetChild(f[1])
  if item=invalid then return
  m.cat=item.id : loadItems(true)
end sub

sub loadItems(reset)
  if reset then m.after=0 : m.items.content=invalid : m.count=0
  if m.loading then return
  m.loading=true : m.status.text="Carregando..."
  params="?a=list&kind=0&cat="+m.cat.toStr()+"&n="+m.pageSize.toStr()
  if m.after>0 then params=params+"&after="+m.after.toStr()
  request(params,"onItems","onError")
end sub

sub onItems(ev)
  r=ev.getData() : m.loading=false
  if r=invalid or r.i=invalid then
    m.status.text="Nenhum canal encontrado" : return
  end if
  content=m.items.content
  if content=invalid then content=CreateObject("roSGNode","ContentNode")
  for each item in r.i
    content.CreateChild("ContentNode").update({p:fitImg(absImg(item.p),48,48),t:item.t,id:item.id,k:0,y:item.y},true)
  end for
  m.items.content=content
  m.count=content.GetChildCount()
  m.more=r.more
  if r.next<>invalid then m.after=r.next
  m.status.text=m.count.toStr()+" canais"
  if not m.cats.isInFocusChain() then m.items.setFocus(true)
end sub

' Foco no canal: pede a prévia do que está passando (guia) para o painel da direita.
sub onItemFocused()
  f=m.items.itemFocused
  if m.more and not m.loading and f<>invalid and f>=m.count-2 then loadItems(false)
  item=m.items.content.GetChild(f)
  if item=invalid then return
  m.focused=item
  showPreview(item)
end sub

sub showPreview(item)
  m.pvTitle.text=item.t
  if item.p<>invalid and item.p<>"" then m.pvLogo.uri=fitImg(absImg(item.p),96,96)
  m.pvNow.text="Buscando guia..." : m.pvNowDesc.text="" : m.pvNext.text=""
  request("?a=epg&id="+item.id.toStr(),"onEpg","onEpgError")
end sub

sub onEpg(ev)
  r=ev.getData()
  if r=invalid then return
  if r.now<>invalid and r.now.title<>invalid then
    m.pvNow.text=programTitle(r.now)
    m.pvNowDesc.text=programDesc(r.now)
  else
    m.pvNow.text="Sem informação no guia" : m.pvNowDesc.text=""
  end if
  if r.next<>invalid and r.next.title<>invalid then
    m.pvNext.text=programTitle(r.next)
  else
    m.pvNext.text="Sem próximos programação"
  end if
end sub

sub onEpgError(ev)
  m.pvNow.text="Sem informação no guia" : m.pvNowDesc.text="" : m.pvNext.text=""
end sub

function programTitle(p) as string
  t=""
  if p.title<>invalid and p.title<>"" then t=p.title
  if p.t0<>invalid and p.t0<>"" then t=p.t0+" · "+t
  return t
end function

function programDesc(p) as string
  d=""
  if p.desc<>invalid then d=p.desc
  if p.t0<>invalid and p.t1<>invalid then d=d+" ("+p.t0+"-"+p.t1+")"
  return d
end function

sub onSelected()
  f=m.items.itemFocused
  if f=invalid then return
  item=m.items.content.GetChild(f)
  if item=invalid then return
  m.scene.callFunc("openLiveItem", item.id, 0, item.t)
end sub

sub onPlaySelected()
  if m.focused=invalid then return
  m.scene.callFunc("openLiveItem", m.focused.id, 0, m.focused.t)
end sub

sub onError(ev)
  m.loading=false : m.status.text="Erro ao carregar canais: "+ev.getData()
end sub

function onKeyEvent(key,press) as boolean
  if not press then return false
  key=LCase(key)
  if key="up" then
    if m.items.isInFocusChain() then
      m.cats.setFocus(true)
    else if m.pvPlay.isInFocusChain() then
      m.items.setFocus(true)
    else
      m.scene.callFunc("focusTopBar")
    end if
    return true
  else if key="down" and m.cats.isInFocusChain() and m.items.content<>invalid then
    m.items.setFocus(true) : return true
  else if key="right" and m.items.isInFocusChain() then
    m.pvPlay.setFocus(true) : return true
  else if key="left" and m.pvPlay.isInFocusChain() then
    m.items.setFocus(true) : return true
  else if (key="ok" or key="select") and m.pvPlay.isInFocusChain() then
    ' pvPlay é um Rectangle (não tem buttonSelected): o OK é tratado aqui.
    onPlaySelected() : return true
  end if
  return false
end function

sub focusContent()
  if m.cats.content<>invalid and m.cats.content.GetChildCount()>0 then m.cats.setFocus(true)
end sub

sub onFocusedChild()
  if m.top.isInFocusChain() and not m.cats.isInFocusChain() and not m.items.isInFocusChain() and not m.pvPlay.isInFocusChain() then focusContent()
end sub
