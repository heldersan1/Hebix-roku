' Cartão de pôster: a imagem carrega no tamanho exato; o título aparece sempre.
sub init()
  m.poster = m.top.findNode("poster")
  m.title = m.top.findNode("title")
  m.titleBg = m.top.findNode("titleBg")
  m.focusRing = m.top.findNode("focusRing")
  m.focusBar = m.top.findNode("focusBar")
  m.poster.observeField("loadStatus", "onStatus")
end sub

sub onItem()
  c = m.top.itemContent
  if c = invalid then return
  if c.p <> invalid then m.poster.uri = c.p else m.poster.uri = "pkg:/images/no-poster.png"
  m.title.text = c.t
  m.title.visible = true
  m.titleBg.visible = true
end sub

sub onStatus()
  ' Title always visible
  m.title.visible = true
  m.titleBg.visible = true
end sub

sub onFocusChange()
  fp = 0.0
  if m.top.focusPercent <> invalid then fp = m.top.focusPercent
  ihf = false
  if m.top.itemHasFocus <> invalid then ihf = m.top.itemHasFocus
  focused = (fp > 0.5) or ihf
  m.focusBar.focusPercent = fp
  m.focusBar.focused = focused
  m.focusRing.visible = focused
  if focused then m.focusRing.opacity = fp
end sub
