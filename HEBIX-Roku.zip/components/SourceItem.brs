sub init()
  m.name = m.top.findNode("name")
  m.meta = m.top.findNode("meta")
  m.mark = m.top.findNode("mark")
  m.focusRing = m.top.findNode("focusRing")
  m.focusBar = m.top.findNode("focusBar")
end sub

sub onItem()
  c = m.top.itemContent
  if c = invalid then return
  m.name.text = c.t
  m.meta.text = c.m
  if c.active = true then
    m.mark.text = "ATIVA"
  else
    m.mark.text = ""
  end if
end sub

sub onFocusChange()
  fp = 0.0
  if m.top.focusPercent <> invalid then fp = m.top.focusPercent
  ihf = false
  if m.top.itemHasFocus <> invalid then ihf = m.top.itemHasFocus
  focused = (fp > 0.5) or ihf
  m.focusBar.focusPercent = fp
  m.focusBar.focused = focused
  m.focusRing.visible = focused
  if focused then
    m.focusRing.opacity = fp
  end if
end sub
