sub init()
  m.top.functionName = "filterChannels"
end sub

sub filterChannels()
  source = m.top.source
  query = LCase(m.top.query)
  filtered = CreateObject("roSGNode", "ContentNode")
  if source = invalid or query = "" then
    m.top.resultContent = filtered
    return
  end if

  for each sourceRow in source
    filteredRow = invalid
    for each channel in sourceRow.channels
      name = ""
      if channel.t <> invalid then name = LCase(channel.t)
      if name.Len() >= query.Len() and name.Left(query.Len()) = query then
        if filteredRow = invalid then
          filteredRow = CreateObject("roSGNode", "ContentNode")
          filteredRow.title = sourceRow.title
          filtered.appendChild(filteredRow)
        end if
        filteredRow.CreateChild("ContentNode").update({
          id: channel.id,
          t: channel.t,
          p: channel.p,
          category: channel.category,
          k: channel.k
        }, true)
      end if
    end for
  end for

  m.top.resultContent = filtered
end sub
