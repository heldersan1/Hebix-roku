sub init()
  m.background = m.top.findNode("background")
  m.activeMark = m.top.findNode("activeMark")
  m.title = m.top.findNode("title")
  m.count = m.top.findNode("count")
  m.focusBar = m.top.findNode("focusBar")
  m.title.font.size = 14
  m.count.font.size = 13
end sub

sub onItem()
  item = m.top.itemContent
  if item = invalid then return
  if item.title <> invalid then m.title.text = liveCategoryLabel(item.title)
  if item.count <> invalid then m.count.text = item.count.toStr()
end sub

sub onFocusChange()
  focused = m.top.itemHasFocus
  if focused = invalid then focused = false
  percent = m.top.focusPercent
  if percent = invalid then percent = 0.0
  focused = focused or percent > 0.5
  m.focusBar.focusPercent = percent
  m.focusBar.focused = focused
  m.background.color = "0x242424FF"
  m.background.visible = focused
  m.activeMark.visible = focused
  m.title.color = "0xF5F5F5FF"
  m.count.color = "0xF5F5F5FF"
end sub
