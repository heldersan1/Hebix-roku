sub init()
  m.logo = m.top.findNode("logo")
  m.placeholder = m.top.findNode("logoPlaceholder")
  m.placeholderText = m.top.findNode("placeholderText")
  m.title = m.top.findNode("title")
  m.group = m.top.findNode("group")
  m.favorite = m.top.findNode("favorite")
  m.live = m.top.findNode("live")
  m.focusBorder = m.top.findNode("focusBorder")
  m.focusBar = m.top.findNode("focusBar")
  m.title.font.size = 14
  m.group.font.size = 12
  m.logo.observeField("loadStatus", "onLogoStatus")
end sub

sub onItem()
  item = m.top.itemContent
  if item = invalid then return
  m.title.text = cleanLiveLabel(item.name)
  groupTitle = item.groupTitle
  if groupTitle = invalid or groupTitle = "" then groupTitle = "Sem categoria"
  m.group.text = liveCategoryLabel(groupTitle)
  m.favorite.visible = false
  if item.isFavorite = true then m.favorite.visible = true
  m.live.visible = false
  if item.isLive = true then m.live.visible = true

  uri = item.logo
  if uri = invalid or uri = "" then
    showPlaceholder()
  else
    m.logo.uri = uri
    m.logo.visible = true
    m.placeholder.visible = false
    m.placeholderText.visible = false
  end if
end sub

sub onLogoStatus()
  if m.logo.loadStatus = "failed" then showPlaceholder()
end sub

sub showPlaceholder()
  m.logo.uri = ""
  m.logo.visible = false
  m.placeholder.visible = true
  m.placeholderText.visible = true
end sub

sub onFocusChange()
  focused = m.top.itemHasFocus
  if focused = invalid then focused = false
  percent = m.top.focusPercent
  if percent = invalid then percent = 0.0
  m.focusBar.focusPercent = percent
  m.focusBar.focused = focused or percent > 0.5
  m.focusBorder.visible = focused or percent > 0.5
end sub
