sub init()
  m.poster = m.top.findNode("poster")
  m.name = m.top.findNode("name")
  m.category = m.top.findNode("category")
  m.focus = m.top.findNode("focus")
  m.focusBar = m.top.findNode("focusBar")
end sub

sub onItem()
  item = m.top.itemContent
  if item = invalid then return
  if item.p <> invalid and item.p <> "" then
    m.poster.uri = item.p
  else
    m.poster.uri = "pkg:/images/no-poster.png"
  end if
  m.name.text = item.t
  m.category.text = item.category
end sub

sub onFocusChange()
  percent = 0.0
  if m.top.focusPercent <> invalid then percent = m.top.focusPercent
  focused = false
  if m.top.itemHasFocus <> invalid then focused = m.top.itemHasFocus
  focused = focused or percent > 0.5
  m.focusBar.focusPercent = percent
  m.focusBar.focused = focused
  m.focus.visible = focused
  if focused then m.focus.opacity = percent
end sub
