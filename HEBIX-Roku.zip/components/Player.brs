' Player D1: reproduz VOD e live HLS usando ContentNode e HttpHeaders nativos.
sub logDebug(message as string)
  print "[D] " + message
end sub

sub init()
  m.scene = m.top.getScene()
  m.server = m.scene.server
  m.profileId = m.scene.profileId
  m.video = m.top.findNode("video")
  ' Reserva memória de decodificação para até 1080p; em alguns Roku a memória
  ' de vídeo é compartilhada com as texturas da interface e streams 4K travam.
  m.video.maxVideoDecodeResolution = [1920, 1080]
  m.overlay = m.top.findNode("overlay")
  m.status = m.top.findNode("status")
  m.backButton = m.top.findNode("backButton")
  m.state = "loading"
  m.tracked = false
  m.activeItem = invalid
  m.preparedItem = invalid
  m.prebufferFailed = false
  m.hasStartedPlayback = false
  m.everPlayed = false
  m.rebufferCount = 0
  m.totalRebufferMs = 0
  m.isRebuffering = false
  m.measuredBitrate = 0
  m.lastBufferPercent = 0
  m.bufferingUnderrun = false
  m.bufferUiTimerPending = false
  m.liveRetryCount = 0
  m.liveFormatFallbackAvailable = false
  m.liveFormatFallbackTried = false
  m.liveFormatSwitchPending = false
  m.liveFormatSwitchTimer = CreateObject("roTimespan")
  m.liveHasStarted = false
  m.isReconnecting = false
  m.liveStartedAt = CreateObject("roTimespan")
  m.bufferingStartedAt = CreateObject("roTimespan")
  m.playStartedAt = CreateObject("roTimespan")
  m.status.visible = false
  m.overlay.visible = false

  ' O Player fica dentro do "stack" (translation [0,56]) para não disputar espaço
  ' com a TopBar. Em reprodução ela fica oculta, então compensamos o offset e
  ' ocupamos a tela inteira (1280x720). Sem isso o vídeo e o botão Voltar ficam
  ' cortados embaixo.
  m.top.translation = [0, -56]

  ' init() roda no CreateObject, antes de o chamador atribuir o campo item.
  ' Por isso o carregamento espera a chegada do item.
  m.top.observeField("item", "onItemSet")
  m.video.observeField("state", "onVideoState")
  m.video.observeField("bufferingStatus", "onBufferingStatus")
  m.video.observeField("streamInfo", "onStreamInfo")
  m.video.observeField("streamingSegment", "onStreamingSegment")
  m.video.observeField("completedStreamInfo", "onCompletedStreamInfo")
  m.video.bufferingBar.visible = false
  m.video.retrievingBar.visible = false
  m.bufferUiTimer = m.top.findNode("bufferUiTimer")
  m.bufferUiTimer.observeField("fire", "onBufferUiTimer")
  m.liveRetryTimer = m.top.findNode("liveRetryTimer")
  m.liveRetryTimer.observeField("fire", "onLiveRetryTimer")
  m.liveBufferTimer = m.top.findNode("liveBufferTimer")
  m.liveBufferTimer.observeField("fire", "onLiveBufferTimeout")
end sub

sub onItemSet(ev)
  item = m.top.item
  if item = invalid or not item.DoesExist("id") or not item.DoesExist("k") then
    showError("Conteúdo inválido")
    return
  end if
  if m.preparedItem <> invalid and m.preparedItem.id = item.id and m.preparedItem.k = item.k
    m.activeItem = item
    if m.prebufferFailed
      m.preparedItem = invalid
      loadItem()
    else
      startPlayback()
    end if
    return
  end if
  m.activeItem = item
  if item.DoesExist("live") and item.live = true
    loadDirectLiveItem(item)
  else
    loadItem()
  end if
end sub

sub loadDirectLiveItem(item as object)
  if not item.DoesExist("u") or item.u = invalid or item.u = ""
    showError("Não foi possível carregar este canal")
    return
  end if
  m.activeItem = item
  m.liveFormatFallbackAvailable = useHlsForExtensionlessLiveItem(item)
  m.liveFormatFallbackTried = false
  if m.liveFormatFallbackAvailable then print "[player-live] format=extensionless_hls"
  content = buildContent(item)
  if content = invalid
    showUnsupported()
    return
  end if
  m.video.content = content
  configureVideoUi(item)
  m.top.playbackState = "loading"
  startPlayback()
end sub

function useHlsForExtensionlessLiveItem(item as object) as boolean
  format = ""
  if item.DoesExist("x") and item.x <> invalid then format = LCase(item.x.toStr())
  if format <> "" then return false
  item.tsUrl = item.u
  item.u = appendUrlExtension(item.u, "m3u8")
  item.x = "m3u8"
  return true
end function

function appendUrlExtension(url as string, extension as string) as string
  insertAt = url.Len() + 1
  queryAt = InStr(1, url, "?")
  fragmentAt = InStr(1, url, "#")
  if queryAt > 0 and queryAt < insertAt then insertAt = queryAt
  if fragmentAt > 0 and fragmentAt < insertAt then insertAt = fragmentAt
  return url.Left(insertAt - 1) + "." + extension + url.Mid(insertAt)
end function

function preparePlayback(item as object) as boolean
  if item = invalid or item.u = invalid or item.u = "" then return false
  if item.k <> 1 and item.k <> 3 then return false
  content = buildContent(item)
  if content = invalid then return false
  m.preparedItem = item
  m.activeItem = item
  m.prebufferFailed = false
  m.hasStartedPlayback = false
  m.everPlayed = false
  m.rebufferCount = 0
  m.totalRebufferMs = 0
  m.isRebuffering = false
  m.measuredBitrate = 0
  m.lastBufferPercent = 0
  m.state = "buffering"
  m.video.content = content
  configureVideoUi(item)
  m.video.control = "prebuffer"
  return true
end function

function buildContent(item as object)
  if item = invalid or not item.DoesExist("u") or item.u = invalid or item.u = "" then return invalid
  format = ""
  if item.DoesExist("x") and item.x <> invalid then format = LCase(item.x.toStr())
  if item.DoesExist("k") and item.k = 0 and format = "" then format = "m3u8"
  streamFormat = rokuFormat(format)
  if streamFormat = "" then return invalid
  content = CreateObject("roSGNode", "ContentNode")
  content.url = item.u
  if item.DoesExist("t") and item.t <> invalid then content.title = item.t
  content.streamformat = streamFormat
  if item.DoesExist("live") and item.live = true then content.live = true
  if item.DoesExist("h") and item.h <> invalid then content.HttpHeaders = normalizeHeaders(item.h)
  return content
end function

sub startPlayback()
  m.hasStartedPlayback = true
  m.playStartedAt.Mark()
  m.state = "loading"
  if not m.everPlayed then startBufferUiTimer(3)
  m.video.control = "play"
end sub

sub stopPlayback()
  m.liveRetryTimer.control = "stop"
  m.liveBufferTimer.control = "stop"
  clearBufferUi()
  m.isReconnecting = false
  if m.video <> invalid then m.video.control = "stop"
  m.hasStartedPlayback = false
  m.preparedItem = invalid
  m.activeItem = invalid
end sub

sub loadItem()
  url = m.server + "?a=item&kind=" + m.top.item.k.toStr() + "&id=" + m.top.item.id.toStr() + "&profile=" + m.profileId

  m.task = CreateObject("roSGNode", "ApiTask")
  m.task.url = url
  m.task.observeField("result", "onItemResult")
  m.task.observeField("error", "onItemError")
  m.task.control = "RUN"
end sub

sub onItemResult(ev)
  r = ev.getData()
  if r = invalid or not r.DoesExist("u") or r.u = "" then
    showError("Não foi possível carregar o conteúdo")
    return
  end if

  contentItem = {id: m.top.item.id, k: m.top.item.k, u: r.u, x: r.x, t: r.t, h: r.h}
  content = buildContent(contentItem)
  if content = invalid
    showUnsupported()
    return
  end if
  m.activeItem = contentItem
  m.video.content = content
  configureVideoUi(contentItem)
  startPlayback()
  if m.top.debug then logDebug("player: playback requested")
end sub

sub onItemError(ev)
  showError("Falha ao carregar o conteúdo")
end sub

function normalizeHeaders(headers) as object
  result = []
  for each header in headers
    separator = InStr(1, header, ":")
    if separator > 0 then
      name = header.Left(separator - 1).Trim()
      value = header.Mid(separator).Trim()
      if name <> "" then result.Push(name + ":" + value)
    end if
  end for
  return result
end function

function rokuFormat(extension) as string
  if extension = "m3u8" then return "hls"
  if extension = "mp4" then return "mp4"
  if extension = "mkv" then return "mkv"
  if extension = "ts" or extension = "mpegts" then return "ts"
  return ""
end function

sub onVideoState(ev)
  state = ev.getData()
  if m.isReconnecting and (state = "stopping" or state = "stopped" or state = "error" or state = "finished") then return
  if state = "buffering" then
    m.bufferingStartedAt.Mark()
    m.lastBufferPercent = 0
    m.bufferingUnderrun = false
    clearBufferUi()
    if m.hasStartedPlayback and not m.everPlayed then startBufferUiTimer(3)
    if isLiveItem()
      print "[player-live] video_state=buffering retries=" + m.liveRetryCount.toStr()
      m.liveBufferTimer.duration = 25
      if m.everPlayed then m.liveBufferTimer.duration = 20
      m.liveBufferTimer.control = "start"
    end if
    if m.hasStartedPlayback and m.everPlayed and m.state <> "paused"
      m.rebufferCount = m.rebufferCount + 1
      m.isRebuffering = true
      print "[player-metrics] rebuffer_start=" + m.rebufferCount.toStr()
    end if
    m.state = "loading"
    if isLiveItem() then m.top.playbackState = "loading"
    ' O Video nativo já exibe o percentual; texto duplicado cobria a imagem.
    m.status.visible = false
    m.overlay.visible = false
    m.backButton.visible = false
  else if state = "playing" then
    clearBufferUi()
    m.bufferingUnderrun = false
    if isLiveItem() then m.liveBufferTimer.control = "stop"
    if m.hasStartedPlayback and not m.everPlayed
      print "[player-metrics] startup_ms=" + m.playStartedAt.TotalMilliseconds().toStr() + " bitrate=" + m.measuredBitrate.toStr() + " rebuffers=" + m.rebufferCount.toStr()
    else if m.isRebuffering
      elapsed = m.bufferingStartedAt.TotalMilliseconds()
      m.totalRebufferMs = m.totalRebufferMs + elapsed
      print "[player-metrics] rebuffer_ms=" + elapsed.toStr() + " total_ms=" + m.totalRebufferMs.toStr()
    end if
    m.isRebuffering = false
    m.everPlayed = true
    m.state = "playing"
    if isLiveItem()
      m.top.playbackState = "playing"
      m.liveStartedAt.Mark()
      m.liveHasStarted = true
    end if
    m.status.visible = false
    m.overlay.visible = false
    m.backButton.visible = false
    if m.top.item.live <> true and not m.tracked then
      m.tracked = true
      trackPlay()
    end if
  else if state = "paused" then
    clearBufferUi()
    if isLiveItem() then m.liveBufferTimer.control = "stop"
    m.state = "paused"
    if m.top.item.live = true then m.top.playbackState = "paused"
    m.status.text = "Pausado"
    m.status.visible = true
    m.overlay.visible = false
    m.backButton.visible = true
    reportProgress()
  else if state = "stopping" then
    clearBufferUi()
    m.state = "stopping"
    m.status.text = "Parando..."
    m.status.visible = true
    m.overlay.visible = true
  else if state = "stopped" then
    clearBufferUi()
    m.state = "stopped"
    m.status.text = "Reprodução parada"
    m.status.visible = true
    m.overlay.visible = true
    m.backButton.visible = true
    m.backButton.setFocus(true)
    reportProgress()
  else if state = "finished" then
    clearBufferUi()
    if isLiveItem()
      if m.liveFormatSwitchPending
        if m.liveFormatSwitchTimer.TotalMilliseconds() < 3000
          print "[player-live] stale_finished=ignored_after_format_switch"
          return
        end if
        m.liveFormatSwitchPending = false
      end if
      completed = m.video.completedStreamInfo
      fullResult = "unknown"
      if completed <> invalid and completed.isFullResult <> invalid then fullResult = completed.isFullResult.toStr()
      print "[player-live] video_state=finished full_result=" + fullResult + "; refreshing stream URL"
      scheduleLiveReconnect()
      return
    end if
    m.state = "finished"
    m.status.text = "Reprodução concluída"
    m.status.visible = true
    m.overlay.visible = true
    m.backButton.visible = true
    m.backButton.setFocus(true)
    reportProgress()
  else if state = "error" then
    clearBufferUi()
    if not m.hasStartedPlayback
      m.prebufferFailed = true
      m.state = "prebuffer-error"
      return
    end if
    if isLiveItem()
      errorCode = m.video.errorCode
      if errorCode = invalid then errorCode = 0
      print "[player-live] video_state=error code=" + errorCode.toStr()
      if errorCode = -3 and tryLiveTsFallback() then return
      scheduleLiveReconnect()
      return
    end if
    showError("Erro ao reproduzir o conteúdo")
  end if
end sub

function tryLiveTsFallback() as boolean
  if not isLiveItem() or not m.liveFormatFallbackAvailable or m.liveFormatFallbackTried then return false
  current = m.activeItem
  if current = invalid then return false
  print "[player-live] format_fallback=hls_to_ts"
  m.liveFormatFallbackTried = true
  m.liveFormatSwitchPending = true
  m.liveFormatSwitchTimer.Mark()
  tsUrl = current.u
  if current.DoesExist("tsUrl") and current.tsUrl <> invalid then tsUrl = current.tsUrl
  item = {id: current.id, k: 0, u: tsUrl, x: "ts", t: current.t, h: current.h, live: true}
  content = buildContent(item)
  if content = invalid then return false
  m.activeItem = item
  configureVideoUi(item)
  m.video.content = content
  startPlayback()
  return true
end function

sub onBufferingStatus(event as object)
  status = event.getData()
  if status = invalid then return
  if status.percentage <> invalid
    percentage = status.percentage
    if isLiveItem() and m.state = "loading" and percentage > m.lastBufferPercent
      elapsed = m.bufferingStartedAt.TotalMilliseconds()
      remaining = 60000 - elapsed
      if remaining > 0
        delay = 20
        if remaining < 20000 then delay = Int(remaining / 1000) + 1
        m.liveBufferTimer.duration = delay
        m.liveBufferTimer.control = "start"
      end if
    end if
    m.lastBufferPercent = percentage
  end if
  if status.isUnderrun = true
    m.bufferingUnderrun = true
    if m.hasStartedPlayback and m.state = "loading" and m.everPlayed then startBufferUiTimer(4)
  end if
end sub

sub onBufferUiTimer(event as object)
  m.bufferUiTimerPending = false
  if m.hasStartedPlayback and m.state = "loading" and (not m.everPlayed or m.bufferingUnderrun)
    if isLiveItem() then m.top.playbackState = "loading"
    if m.everPlayed then
      m.video.bufferingBar.visible = true
    else
      m.video.retrievingBar.visible = true
    end if
  end if
end sub

sub startBufferUiTimer(delaySeconds as float)
  if m.bufferUiTimerPending then return
  m.bufferUiTimer.duration = delaySeconds
  m.bufferUiTimerPending = true
  m.bufferUiTimer.control = "start"
end sub

sub clearBufferUi()
  m.bufferUiTimer.control = "stop"
  m.bufferUiTimerPending = false
  hideBufferIndicators()
end sub

sub hideBufferIndicators()
  m.video.bufferingBar.visible = false
  m.video.retrievingBar.visible = false
end sub

sub onStreamInfo(event as object)
  info = event.getData()
  if info = invalid then return
  bitrate = info.measuredBItrate
  if bitrate = invalid then bitrate = info.measuredBitrate
  if bitrate <> invalid then m.measuredBitrate = bitrate
end sub

sub onCompletedStreamInfo(event as object)
  info = event.getData()
  if info = invalid or not isLiveItem() then return
  fullResult = "unknown"
  if info.isFullResult <> invalid then fullResult = info.isFullResult.toStr()
  bitrate = "unknown"
  if info.streamBitrate <> invalid then bitrate = info.streamBitrate.toStr()
  print "[player-live] completed full_result=" + fullResult + " stream_bps=" + bitrate
end sub

sub onStreamingSegment(event as object)
  info = event.getData()
  if info = invalid or not isLiveItem() then return
  width = 0
  height = 0
  bitrate = 0
  latency = 0
  if info.width <> invalid then width = info.width
  if info.height <> invalid then height = info.height
  if info.segBitrateBps <> invalid then bitrate = info.segBitrateBps
  if info.latency <> invalid then latency = info.latency
  print "[player-live] segment=" + width.toStr() + "x" + height.toStr() + " bitrate_bps=" + bitrate.toStr() + " latency_ms=" + latency.toStr()
end sub

sub configureVideoUi(item as object)
  live = item <> invalid and item.DoesExist("live") and item.live = true
  ' O player nativo mostra sua própria barra ao detectar buffering; em canais
  ' ao vivo isso confundia o fim normal de segmentos curtos com interrupção.
  m.video.enableUI = not live
end sub

function isLiveItem() as boolean
  return m.activeItem <> invalid and m.activeItem.DoesExist("live") and m.activeItem.live = true
end function

sub scheduleLiveReconnect()
  if not isLiveItem() then return
  if m.isReconnecting then return
  m.liveBufferTimer.control = "stop"
  clearBufferUi()
  if m.liveHasStarted and m.liveStartedAt.TotalMilliseconds() > 60000 then m.liveRetryCount = 0
  if m.liveRetryCount >= 3
    showError("Transmissão interrompida. Pressione Play para tentar novamente.")
    return
  end if
  m.liveRetryCount = m.liveRetryCount + 1
  m.isReconnecting = true
  m.state = "reconnecting"
  ' Não enviar STOP durante a recuperação: o comando limpa o quadro atual e
  ' causa a tela preta antes mesmo de a nova URL estar pronta. A troca de
  ' content reinicia o player quando a resposta da API chega.
  m.top.playbackState = "loading"
  ' Recupera em segundo plano sem cobrir o vídeo com mensagens/overlay.
  m.status.visible = false
  m.overlay.visible = false
  m.backButton.visible = false
  retryDelay = 1
  if m.liveRetryCount = 2 then retryDelay = 2
  if m.liveRetryCount >= 3 then retryDelay = 4
  m.liveRetryTimer.duration = retryDelay
  m.liveRetryTimer.control = "start"
end sub

sub onLiveBufferTimeout(event as object)
  if isLiveItem() and m.state = "loading"
    print "[player-live] buffering_timeout_ms=15000"
    scheduleLiveReconnect()
  end if
end sub

sub onLiveRetryTimer(event as object)
  if not isLiveItem() or m.liveRetryTask <> invalid then return
  task = CreateObject("roSGNode", "ApiTask")
  task.url = m.server + "?a=live_item&id=" + m.activeItem.id.toStr()
  task.observeField("result", "onLiveRefreshResult")
  task.observeField("error", "onLiveRefreshError")
  m.liveRetryTask = task
  task.control = "RUN"
end sub

sub finishLiveRetryTask()
  m.liveRetryTask = invalid
end sub

sub onLiveRefreshResult(event as object)
  result = event.getData()
  finishLiveRetryTask()
  if not isLiveItem() then return
  if result = invalid or result.streamUrl = invalid or result.streamUrl = ""
    m.isReconnecting = false
    scheduleLiveReconnect()
    return
  end if
  format = result.ext
  item = {id: result.id, k: 0, u: result.streamUrl, x: format, t: result.name, h: result.headers, live: true}
  m.liveFormatFallbackAvailable = false
  if format = invalid or format = ""
    if m.liveFormatFallbackTried
      item.x = "ts"
    else
      m.liveFormatFallbackAvailable = useHlsForExtensionlessLiveItem(item)
      if m.liveFormatFallbackAvailable then print "[player-live] format=extensionless_hls"
    end if
  end if
  content = buildContent(item)
  if content = invalid
    showUnsupported()
    return
  end if
  m.isReconnecting = false
  m.activeItem = item
  configureVideoUi(item)
  m.video.content = content
  startPlayback()
end sub

sub onLiveRefreshError(event as object)
  finishLiveRetryTask()
  if isLiveItem()
    m.isReconnecting = false
    scheduleLiveReconnect()
  end if
end sub

sub showUnsupported()
  m.isReconnecting = false
  m.liveBufferTimer.control = "stop"
  m.state = "unsupported"
  if m.top.item <> invalid and m.top.item.live = true then m.top.playbackState = "error"
  m.status.text = "Formato não suportado pela Roku"
  m.status.visible = true
  m.overlay.visible = true
  m.backButton.visible = true
  m.backButton.setFocus(true)
end sub

sub showError(message)
  m.isReconnecting = false
  m.state = "error"
  if m.top.item <> invalid and m.top.item.live = true then m.top.playbackState = "error"
  m.status.text = message
  m.status.visible = true
  m.overlay.visible = true
  m.backButton.visible = true
  m.backButton.setFocus(true)
end sub

' Salva a posição para "Continuar assistindo" na home.
sub reportProgress()
  if m.top.item = invalid then return
  if m.top.item.k = 0 then return
  posSec = m.video.position
  dur = m.video.duration
  if posSec = invalid or dur = invalid then return
  if posSec <= 0 or dur <= 1 then return
  t = CreateObject("roSGNode", "ApiTask")
  t.url = m.server + "?a=prog"
  t.postData = "kind=" + m.top.item.k.toStr() + "&ref=" + m.top.item.id.toStr() + "&pos=" + posSec.toStr() + "&dur=" + dur.toStr() + "&profile=" + m.profileId
  t.observeField("result", "onProgressOk")
  t.observeField("error", "onProgressError")
  t.control = "RUN"
end sub

sub onProgressOk()
end sub

' Conta a reprodução para a linha "Mais vistos" (uma vez por abertura do player).
sub trackPlay()
  if m.top.item = invalid then return
  t = CreateObject("roSGNode", "ApiTask")
  t.url = m.server + "?a=play"
  t.postData = "kind=" + m.top.item.k.toStr() + "&ref=" + m.top.item.id.toStr()
  t.control = "RUN"
end sub

sub onProgressError(ev)
  print "[nav] prog error: " + ev.getData()
end sub

function onKeyEvent(key, press) as boolean
  if not press then return false
  command = lowerCase(key)
  if command = "pause" then
    if m.state = "playing" or m.state = "loading" then m.video.control = "pause"
    return true
  else if command = "play" then
    ' O controle remoto usa a mesma tecla para Play/Pause.
    if m.state = "paused" then
      m.video.control = "resume"
      m.state = "playing"
      m.status.visible = false
      m.backButton.visible = false
    else if m.state = "playing" or m.state = "loading" then
      m.video.control = "pause"
      m.state = "paused"
      m.status.text = "Pausado"
      m.status.visible = true
      m.overlay.visible = false
      m.backButton.visible = true
    else if m.state = "stopped" or m.state = "finished" or m.state = "none" then
      m.video.control = "play"
      m.state = "loading"
      m.status.visible = false
      m.overlay.visible = false
      m.backButton.visible = true
    else if m.state = "error" then
      if isLiveItem()
        m.liveRetryCount = 0
        scheduleLiveReconnect()
      else
        loadItem()
      end if
    end if
    return true
  else if command = "stop" then
    m.video.control = "stop"
    m.state = "stopping"
    m.status.text = "Parando..."
    m.status.visible = true
    m.overlay.visible = true
    m.backButton.visible = true
    return true
  else if command = "instantreplay" then
    m.video.control = "replay"
    return true
  else if command = "back" then
    reportProgress()
    m.video.control = "stop"
    m.scene.callFunc("pop")
    return true
  end if
  ' Rewind/FastForward sao tratados nativamente pelo Video/trickplay.
  return false
end function

sub focusContent()
  m.video.setFocus(true)
end sub
