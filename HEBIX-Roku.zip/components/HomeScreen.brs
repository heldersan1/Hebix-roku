' Home 1920x1080: hero e linhas unificadas em uma única RowList.
sub init()
  m.scene = m.top.getScene()
  m.topBar = m.scene.findNode("topBar")
  m.base = origin(m.scene.server)
  m.api = m.scene.server
  if m.api = invalid or m.api = "" then
    if m.scene <> invalid then m.scene.callFunc("openSetup")
    return
  end if
  m.rows = m.top.findNode("rows")
  m.heroBackdrop = m.top.findNode("heroBackdrop")
  m.heroPoster = m.top.findNode("heroPoster")
  m.heroTitle = m.top.findNode("heroTitle")
  m.heroMeta = m.top.findNode("heroMeta")
  m.heroDesc = m.top.findNode("heroDesc")
  m.homeStatus = m.top.findNode("homeStatus")
  m.heroActions = m.top.findNode("heroActions")
  m.playBtn = m.top.findNode("playBtn")
  m.listBtn = m.top.findNode("listBtn")
  m.heroTimer = m.top.findNode("heroTimer")
  m.carouselTimer = m.top.findNode("carouselTimer")
  m.rows.observeField("rowItemFocused", "onItemFocused")
  m.rows.observeField("rowItemSelected", "onItemSelected")
  m.heroTimer.observeField("fire", "onHeroFire")
  m.carouselTimer.observeField("fire", "onCarouselFire")
  m.idleTimer = m.top.findNode("idleTimer")
  m.idleTimer.observeField("fire", "onIdleFire")
  m.top.observeField("focusedChild", "onFocusedChild")
  ' Ao voltar de outra tela (ex.: favoritar um título), a home recarrega.
  m.top.observeField("reload", "onReload")
  m.page = 1
  m.pageSize = 30
  m.generation = 0
  m.lastRowId = ""
  m.loadingMore = false
  m.carousel = []
  m.carouselIdx = 0
  m.autoRotate = true
  m.listBtnFocused = false
  m.heroId = invalid
  m.heroKind = invalid
  
  ' Check for preloaded data from MainScene
  m.preloadData = invalid
  scene = m.top.getScene()
  if scene <> invalid and scene.homePreloadData <> invalid then
    m.preloadData = scene.homePreloadData
    scene.homePreloadData = invalid
    buildRows(m.preloadData)
    buildCarousel(m.preloadData)
  else
    loadHome(false)
  end if
end sub

function origin(url) as string
  p = InStr(0, url, "//")
  if p < 0 then return url
  p += 2
  s = InStr(p, url, "/")
  if s > 0 then return url.Left(s - 1)
  return url
end function

function absImg(path) as string
  if path = invalid or path = "" then return ""
  if path.Left(4) = "http" then return path
  return m.base + path
end function

' Recarrega do zero (usado ao voltar de outra tela). Sem isso a home mostrava
' dados velhos: favoritos novos só apareciam depois de reiniciar o app.
sub onReload(ev)
  m.page = 1
  m.lastRowId = ""
  m.loadingMore = false
  loadHome(false)
end sub

sub loadHome(nextOnly)
  m.generation = m.generation + 1
  req = CreateObject("roSGNode", "ApiTask")
  params = "&n=" + m.pageSize.toStr() + "&v=" + m.top.reload.toStr() + "&g=" + m.generation.toStr()
  if m.page > 1 then params = params + "&after=" + m.lastRowId
  req.url = m.api + "?a=home&profile=" + m.scene.profileId + params
  req.observeField("result", "onHomeResult")
  req.observeField("error", "onHomeError")
  req.control = "RUN"
end sub

sub onHomeResult(ev)
  req = ev.getRoSGNode()
  if generationFromUrl(req.url) <> m.generation then return
  r = ev.getData()
  if r = invalid then return
  m.homeStatus.visible = false
  if r.more <> invalid then m.totalRows = r.more
  if r.next <> invalid then m.lastRowId = r.next
  buildRows(r)
  buildCarousel(r)
end sub

' Carrossel de capas: a linha "rail" do servidor vira a fila do herói.
sub buildCarousel(r)
  m.carousel = []
  for each row in r.rows
    if row.id = "rail" then
      for each it in row.i
        m.carousel.push({ t: it.t, y: it.y, k: it.k, p: it.p, o: it.o, b: it.b })
      end for
      exit for
    end if
  end for
  m.carouselIdx = 0
  m.autoRotate = true
  if m.carousel.Count() > 0 then
    setHero(m.carousel[0])
    m.carouselTimer.control = "start"
  end if
end sub

sub onHomeError(ev)
  req = ev.getRoSGNode()
  if generationFromUrl(req.url) <> m.generation then return
  print "[nav] HomeScreen onHomeError " + ev.getData()
  m.page = 1
  m.loadingMore = false
  m.homeStatus.text = "Não foi possível carregar o catálogo. Use o menu para tentar novamente."
  m.homeStatus.visible = true
  if m.top.visible then m.scene.callFunc("focusTopBar")
end sub

function generationFromUrl(url as string) as integer
  marker = url.instr("&g=")
  if marker < 0 then return -1
  return url.mid(marker + 3).tokenize("&")[0].toInt()
end function

sub buildRows(r)
  root = CreateObject("roSGNode", "ContentNode")
  rowItemSizes = []
  rowHeights = []
  rowSpacings = []

  for each row in r.rows
    if row.i = invalid or row.i.Count() = 0 then continue for
    ' O RowList usa itemComponentName="HomeItem" (fixo). O HomeItem alterna
    ' entre cartao 160x240 e faixa 320x180 conforme o campo kind do item.
    ' "Continuar assistindo" recebe kind="landscape".
    isCw = (row.id = "cw" or row.t = "Continuar assistindo")
    rn = root.CreateChild("ContentNode")
    rn.title = row.t
    iw = 320 : ih = 180
    if not isCw then iw = 160 : ih = 240
    for each it in row.i
      itn = rn.CreateChild("ContentNode")
      itemKind = "poster"
      imageW = iw : imageH = ih
      if isCw then itemKind = "landscape"
      if isCw and it.k = 0 then
        itemKind = "channel"
        imageH = 136
      end if
      itn.update({ p: fitImg(absImg(it.p), imageW, imageH), t: it.t, id: it.id, k: it.k, y: it.y, o: it.o, b: it.b, kind: itemKind }, true)
    end for
    if isCw
      rowItemSizes.push([320, 180])
    else
      rowItemSizes.push([160, 240])
    end if
    rowHeights.push(280)
    rowSpacings.push(18)
  end for
  m.rows.content = root
  m.rows.rowItemSize = rowItemSizes
  m.rows.rowHeights = rowHeights
  m.rows.rowSpacings = rowSpacings
  if root.GetChildCount() > 0 and m.top.visible and not m.topBar.isInFocusChain() then m.rows.setFocus(true)
end sub

sub onHeroItemResult(ev)
  r = ev.getData()
  if r = invalid then return
  if r.id = invalid or m.heroId = invalid then return
  if r.id.toStr() <> m.heroId.toStr() then return
  if r.b <> invalid and r.b <> "" then m.heroBackdrop.uri = absImg(r.b)
  if r.o <> invalid and r.o <> "" then m.heroDesc.text = r.o
end sub

sub onHeroItemError(ev)
  ' erro no detalhe do hero não bloqueia a Home
end sub

sub onItemFocused()
  ' ao navegar, o herói para de girar e mostra o item em foco;
  ' após alguns segundos parado, o carrossel volta sozinho.
  m.autoRotate = false
  m.carouselTimer.control = "stop"
  m.idleTimer.control = "start"
  m.heroTimer.control = "start"
end sub

sub onIdleFire()
  ' carrossel volta a girar quando o usuário para de navegar
  m.autoRotate = true
  if m.carousel.Count() > 0 then m.carouselTimer.control = "start"
end sub

sub onHeroFire()
  f = m.rows.rowItemFocused
  if f = invalid or f.Count() < 2 then return
  row = m.rows.content.GetChild(f[0])
  if row = invalid then return
  it = row.GetChild(f[1])
  if it = invalid then return
  m.heroId = it.id
  setHero({ t: it.t, y: it.y, k: it.k, p: it.p, o: it.o, b: it.b })
  if it.o <> invalid and it.o <> "" then return
  t = CreateObject("roSGNode", "ApiTask")
  t.url = m.api + "?a=item&kind=" + it.k.toStr() + "&id=" + it.id.toStr() + "&profile=" + m.scene.profileId
  t.observeField("result", "onHeroItemResult")
  t.observeField("error", "onHeroItemError")
  t.control = "RUN"
end sub

sub onItemSelected()
  f = m.rows.rowItemFocused
  if f = invalid or f.Count() < 2 then return
  row = m.rows.content.GetChild(f[0])
  if row = invalid then return
  it = row.GetChild(f[1])
  if it = invalid then return
  m.top.selected = { id: it.id, k: it.k, t: it.t }
end sub

sub setHero(it)
  if it = invalid or it.t = invalid then return
  m.heroTitle.color = design().text
  m.heroTitle.text = it.t
  meta = ""
  if it.k <> invalid then meta = mediaTypeName(it.k)
  if it.y <> invalid and it.y > 0 then meta = it.y.toStr() + " · " + meta
  m.heroMeta.text = meta
  if it.o <> invalid and it.o <> "" then
    m.heroDesc.text = it.o
  else
    m.heroDesc.text = " "
  end if
  ' fitImg evita esticar: o proxy devolve a imagem já no formato de cada caixa.
  img = ""
  if it.b <> invalid and it.b <> "" then img = it.b
  if img = "" and it.p <> invalid then img = it.p
  if img <> "" then
    m.heroBackdrop.uri = fitImg(absImg(img), 1280, 280)
    m.heroPoster.uri = fitImg(absImg(img), 180, 270)
  else
    m.heroBackdrop.uri = "pkg:/images/hero-gradient.png"
    m.heroPoster.uri = "pkg:/images/no-poster.png"
  end if
end sub


sub addHeroToFav()
  if m.heroId = invalid then return
  t = CreateObject("roSGNode", "ApiTask")
  t.url = m.api + "?a=fav&profile=" + m.scene.profileId
  t.postData = "kind=" + m.heroKind.toStr() + "&id=" + m.heroId.toStr()
  t.observeField("result", "onAddFavResult")
  t.observeField("error", "onAddFavError")
  t.control = "RUN"
end sub

sub onAddFavResult(ev)
  r = ev.getData()
  if r = invalid then return
  if r.fav <> invalid then
    if r.fav <> 0 then
      m.listLabel.text = "Na minha lista"
    else
      m.listLabel.text = "Minha lista"
    end if
  end if
  m.top.reload = m.top.reload + 1
end sub

sub onAddFavError(ev)
  print "[nav] add to fav error: " + ev.getData()
end sub

function mediaTypeName(mediaKind) as string
  if mediaKind = 1 then return "Filme"
  if mediaKind = 2 then return "Série"
  if mediaKind = 0 then return "Ao vivo"
  return ""
end function

' RowList não tem rowFocused: o índice da linha focada é rowItemFocused[0].
function navAtFirstRow(list) as boolean
  f = list.rowItemFocused
  return f <> invalid and f.Count() > 1 and f[0] = 0
end function

function onKeyEvent(key, press) as boolean
  if not press then return false
  key = LCase(key)
  hasRows = false
  if m.rows.content <> invalid then hasRows = m.rows.content.GetChildCount() > 0
  if key = "back" and not hasRows
    m.scene.callFunc("focusTopBar")
    return true
  end if
  if m.listBtnFocused and key = "ok"
    addHeroToFav()
    return true
  end if
  if key = "up" and m.rows.isInFocusChain() and navAtFirstRow(m.rows)
    m.scene.callFunc("focusTopBar")
    return true
  end if
  return false
end function

sub focusContent()
  if m.rows.content <> invalid and m.rows.content.GetChildCount() > 0 then
    m.rows.setFocus(true)
  else
    m.scene.callFunc("focusTopBar")
  end if
end sub

sub onScreenHidden()
  m.carouselTimer.control = "stop"
  m.idleTimer.control = "stop"
  m.heroTimer.control = "stop"
end sub

sub onScreenShown()
  if m.carousel.Count() > 0
    if m.autoRotate then
      m.carouselTimer.control = "start"
    else
      m.idleTimer.control = "start"
    end if
  end if
end sub

sub onFocusedChild()
  if m.top.isInFocusChain() and not m.rows.isInFocusChain() then
    focusContent()
  end if
end sub
