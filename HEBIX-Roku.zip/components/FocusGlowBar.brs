sub init()
  m.outerGlow = m.top.findNode("outerGlow")
  m.innerGlow = m.top.findNode("innerGlow")
  m.shine = m.top.findNode("shine")
  m.core = m.top.findNode("core")
  onBarWidth()
  onFocusChange()
end sub

sub onBarWidth()
  width = m.top.barWidth
  if width = invalid then return
  m.outerGlow.width = width
  m.innerGlow.width = width
  m.shine.width = width
  m.core.width = width
end sub

sub onFocusChange()
  percent = m.top.focusPercent
  if percent = invalid then percent = 0.0
  focused = false
  if m.top.focused <> invalid then focused = m.top.focused
  if not focused and percent <= 0.05
    m.top.visible = false
    return
  end if
  m.top.visible = true
  if focused and percent < 0.7 then percent = 0.7
  m.outerGlow.opacity = percent * 0.45
  m.innerGlow.opacity = percent * 0.7
  m.shine.opacity = percent
  m.core.opacity = percent
end sub
