' Generic API task: GET/POST assíncrono, JSON, timeout de 8 s e retry de transporte.
sub init()
  m.top.functionName = "execute"
end sub

function readToken() as string
  sec = CreateObject("roRegistrySection", "setup")
  v = sec.Read("token")
  if v = invalid then return ""
  return v
end function

sub execute()
  token = ""
  if m.top.token <> invalid and m.top.token <> "" then
    token = m.top.token
  else
    token = readToken()
  end if
  lastErr = ""
  for attempt = 1 to 2
    req = CreateObject("roUrlTransfer")
    req.SetUrl(m.top.url)
    req.EnableEncodings(true)
    req.SetCertificatesFile("common:/certs/ca-bundle.crt")
    req.InitClientCertificates()
    if token <> "" then req.AddHeader("X-Key", token)
    port = CreateObject("roMessagePort")
    req.SetMessagePort(port)

    if m.top.postData <> invalid and m.top.postData <> "" then
      req.AddHeader("Content-Type", "application/x-www-form-urlencoded")
      ' roUrlTransfer nao tem AsyncPostToString: o metodo correto e AsyncPostFromString.
      started = req.AsyncPostFromString(m.top.postData)
    else
      started = req.AsyncGetToString()
    end if
    if not started
      lastErr = "Falha ao iniciar a requisição"
      exit for
    end if

    timeoutMs = 8000
    if m.top.timeoutMs <> invalid and m.top.timeoutMs > 0 then timeoutMs = m.top.timeoutMs
    msg = wait(timeoutMs, port)
    if type(msg) = "roUrlEvent"
      code = msg.GetResponseCode()
      if code > 0
        ' Resposta HTTP recebida: não faz retry (inclui 4xx/5xx)
        if code = 200
          body = msg.GetString()
          parsed = ParseJson(body)
          if parsed = invalid
            lastErr = "Resposta inválida do servidor"
            exit for
          end if
          if type(parsed) = "roArray"
            m.top.result = { data: parsed }
          else
            m.top.result = parsed
          end if
          return
        end if
        lastErr = "HTTP " + code.toStr()
        reason = msg.GetFailureReason()
        if reason <> invalid and reason <> "" then lastErr = lastErr + " (" + reason + ")"
        exit for
      end if
      ' code <= 0: falha de conexão/transporte
      lastErr = "Falha de conexão (" + code.toStr() + ")"
      reason = msg.GetFailureReason()
      if reason <> invalid and reason <> "" then lastErr = lastErr + " - " + reason
      req.AsyncCancel()
    else
      ' timeout (sem evento)
      req.AsyncCancel()
      lastErr = "Tempo esgotado (" + timeoutMs.toStr() + " ms)"
      reason = invalid
    end if

    if attempt = 2 then exit for
    ' retry silencioso apenas para timeout/falha de conexão
  end for

  m.top.error = lastErr
end sub
