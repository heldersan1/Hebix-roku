' Setup enxuto: URL -> token opcional -> teste (a=home&n=30) -> salva e conclui.
sub init()
  m.scene = m.top.getScene()
  m.msg = m.top.findNode("msg")
  m.msg.color = theme().accent
  m.dlg = invalid
  m.retry = false
  m.serverUrl = ""
  m.tokenVal = ""
  askUrl()
end sub

sub focusContent()
  if m.dlg <> invalid then m.dlg.setFocus(true) else m.top.setFocus(true)
end sub

sub askUrl()
  m.msg.text = ""
  d = CreateObject("roSGNode", "StandardKeyboardDialog")
  d.title = "Endereço da API (ex.: https://hebix.fly.dev/api.php)"
  ' Sugere o Fly.io se não houver nada salvo
  defaultUrl = reg("server")
  if defaultUrl = "" then defaultUrl = "https://hebix.fly.dev/api.php"
  d.text = defaultUrl
  d.buttons = ["Continuar"]
  d.keyboardDomain = "generic"
  d.observeField("buttonSelected", "onUrlOk")
  d.observeField("wasClosed", "onDlgClosed")
  m.scene.dialog = d
  m.dlg = d
  d.setFocus(true)
  if d.textEditBox <> invalid then d.textEditBox.setFocus(true)
end sub

sub onDlgClosed(ev)
  ' Back no diálogo cancela sem travar
  m.dlg = invalid
end sub

sub onUrlOk(ev)
  if type(ev.getData()) <> "roInt" or ev.getData() <> 0 or m.dlg = invalid then return
  raw = m.dlg.text.trim()
  ' campo pode vir contaminado com a URL repetida; fica só até o fim do 1º api.php
  i = raw.InStr("api.php")
  if i >= 0 and i + 7 < raw.Len() then raw = raw.Left(i + 7)
  url = apiUrl(raw)
  if url.Len() < 8 or url.Left(4) <> "http"
    fail("Informe o endereço completo começando com http:// ou https://")
    askUrl()
    return
  end if
  m.serverUrl = url
  askToken()
end sub

sub askToken()
  m.msg.text = ""
  d = CreateObject("roSGNode", "StandardKeyboardDialog")
  d.title = "Token do servidor (opcional)"
  d.text = reg("token")
  d.buttons = ["Pular", "Salvar"]
  d.keyboardDomain = "password"
  d.observeField("buttonSelected", "onTokenOk")
  d.observeField("wasClosed", "onDlgClosed")
  m.scene.dialog = d
  m.dlg = d
  d.setFocus(true)
  if d.textEditBox <> invalid then d.textEditBox.setFocus(true)
end sub

sub onTokenOk(ev)
  idx = ev.getData()
  if type(idx) <> "roInt" then return
  if m.dlg = invalid then return
  if idx = 1 and m.dlg.text.trim() <> ""
    m.tokenVal = m.dlg.text.trim()
  else
    ' Pular deixa vazio; servidores protegidos exigem o token configurado.
    m.tokenVal = ""
  end if
  m.scene.dialog = invalid
  m.dlg = invalid
  m.msg.text = "Testando servidor..."
  testServer(m.serverUrl, m.tokenVal)
end sub

sub testServer(url, token)
  t = CreateObject("roSGNode", "ApiTask")
  t.url = url + "?a=home&n=30"
  t.token = token
  t.observeField("result", "onTestResult")
  t.observeField("error", "onTestError")
  t.control = "RUN"
end sub

sub onTestResult(ev)
  r = ev.getData()
  rlog = "inv"
  if r <> invalid then rlog = FormatJson(r).Left(120)
  if r = invalid or r.rows = invalid
    fail("Resposta inválida do servidor")
    return
  end if
  regWrite("server", m.serverUrl)
  regWrite("token", m.tokenVal)
  m.scene.server = m.serverUrl
  m.msg.text = ""
  m.top.done = true
end sub

sub onTestError(ev)
  err = ev.getData()
  print "[nav] setup onTestError=" + err
  if InStr(1, err, "HTTP 403") > 0
    fail("Token inválido ou acesso não autorizado (HTTP 403)")
  else
    fail(err)
  end if
end sub

sub fail(reason)
  m.msg.text = "Erro: " + reason + " - pressione OK para tentar novamente"
  m.retry = true
end sub

' OK reabre o fluxo após uma falha
function onKeyEvent(key, press) as boolean
  key = LCase(key)
  if press and (key = "ok" or key = "options") and m.retry
    m.retry = false
    askUrl()
    return true
  end if
  return false
end function

function reg(key) as string
  sec = CreateObject("roRegistrySection", "setup")
  v = sec.Read(key)
  if v = invalid then v = ""
  return v
end function

sub regWrite(key, val)
  sec = CreateObject("roRegistrySection", "setup")
  sec.Write(key, val)
  sec.Flush()
end sub
