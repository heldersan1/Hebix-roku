' Netflix-style loading screen with pulse animation
sub init()
  print "[LoadingScreen] init started"
  m.logoCircle = m.top.findNode("logoCircle")
  m.playIcon = m.top.findNode("playIcon")
  m.logoText = m.top.findNode("logoText")
  m.barBg = m.top.findNode("barBg")
  m.barFill = m.top.findNode("barFill")
  m.loadingText = m.top.findNode("loadingText")
  
  m.progress = 0.0
  m.pulseDirection = 1
  m.pulseScale = 1.0
  m.loaded = false
  
  ' Start pulse animation
  m.pulseTimer = createObject("roSGNode", "Timer")
  m.pulseTimer.duration = 0.03
  m.pulseTimer.repeat = true
  m.pulseTimer.observeField("fire", "onPulse")
  m.pulseTimer.control = "start"
  
  ' Simulate loading progress
  m.progressTimer = createObject("roSGNode", "Timer")
  m.progressTimer.duration = 0.05
  m.progressTimer.repeat = true
  m.progressTimer.observeField("fire", "onProgressTick")
  m.progressTimer.control = "start"
  
  m.top.observeField("progress", "onProgress")
  print "[LoadingScreen] init complete, timers started"
end sub

sub onPulse()
  ' Pulse the logo circle (Netflix-style)
  m.pulseScale = m.pulseScale + (0.01 * m.pulseDirection)
  if m.pulseScale >= 1.05 then m.pulseDirection = -1
  if m.pulseScale <= 0.95 then m.pulseDirection = 1
  
  center = 60
  radius = int(center * m.pulseScale)
  m.logoCircle.width = radius * 2
  m.logoCircle.height = radius * 2
  m.logoCircle.translation = [-radius, -radius]
  
  ' Pulse play icon too
  if m.playIcon <> invalid then
    scale = m.pulseScale
    iconSize = int(48 * scale)
    m.playIcon.width = iconSize
    m.playIcon.height = iconSize
    m.playIcon.translation = [-iconSize/2, -iconSize/2]
  end if
end sub

sub onProgressTick()
  if m.progress < 1.0 then
    m.progress = m.progress + 0.02
    m.top.progress = m.progress
    updateProgressBar()
  else
    m.progressTimer.control = "stop"
    m.loaded = true
    ' Emit loaded event
    m.top.progress = 1.0
    print "[LoadingScreen] Loading complete"
  end if
end sub

sub updateProgressBar()
  w = int(300 * m.progress)
  m.barFill.width = w
  if m.progress < 0.3 then
    m.loadingText.text = "Carregando catálogo..."
  else if m.progress < 0.6 then
    m.loadingText.text = "Carregando canais..."
  else if m.progress < 0.9 then
    m.loadingText.text = "Preparando interface..."
  else
    m.loadingText.text = "Pronto!"
  end if
end sub

sub onProgress()
  updateProgressBar()
end sub

sub focusContent()
  ' Nothing to focus on loading screen
end sub