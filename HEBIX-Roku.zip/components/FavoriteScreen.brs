sub init()
  m.scene = m.top.getScene()
  m.base = origin(m.scene.server)
  m.api = m.scene.server
  m.items = m.top.findNode("items")
  m.status = m.top.findNode("status")
  m.spinner = m.top.findNode("spinner")
  m.filters = m.top.findNode("filters")
  m.filterBgs = [m.top.findNode("filter0Bg"), m.top.findNode("filter1Bg"), m.top.findNode("filter2Bg")]
  m.filterLabels = [m.top.findNode("filter0"), m.top.findNode("filter1"), m.top.findNode("filter2")]
  m.filterGlows = [m.top.findNode("filterGlow0"), m.top.findNode("filterGlow1"), m.top.findNode("filterGlow2")]
  m.filterIndex = 0
  m.favoriteRows = []
  m.items.observeField("itemSelected", "onSelected")
  m.items.observeField("itemFocused", "onItemFocused")
  m.top.observeField("reload", "loadFavorites")
  loadFavorites()
end sub

sub loadFavorites()
  m.spinner.visible = true
  m.spinner.control = "start"
  m.status.text = "Carregando favoritos..."
  task = CreateObject("roSGNode", "ApiTask")
  task.url = m.api + "?a=favorites&profile=" + m.scene.profileId
  task.observeField("result", "onResult")
  task.observeField("error", "onError")
  task.control = "RUN"
end sub

sub onResult(event as object)
  result = event.getData()
  m.spinner.control = "stop"
  m.spinner.visible = false
  m.favoriteRows = []
  if result <> invalid and result.items <> invalid
    for each item in result.items
      category = item.category
      if category = invalid or category = "" then category = "Sem categoria"
      m.favoriteRows.Push({p: fitImg(absImg(item.p), 64, 96), t: item.t, id: item.id, k: item.k, y: item.y, category: category})
    end for
  end if
  renderFavorites()
end sub

sub renderFavorites()
  content = CreateObject("roSGNode", "ContentNode")
  selectedKind = m.filterIndex + 1
  for each item in m.favoriteRows
    if (selectedKind = 1 and item.k = 1) or (selectedKind = 2 and (item.k = 2 or item.k = 3)) or (selectedKind = 3 and (item.k = 0 or item.k = 4))
      content.CreateChild("ContentNode").update(item, true)
    end if
  end for
  m.items.content = content
  paintFilters()
  count = content.GetChildCount()
  if count = 0
    if selectedKind = 1
      m.status.text = "Nenhum filme favorito."
    else if selectedKind = 2
      m.status.text = "Nenhuma série favorita."
    else
      m.status.text = "Nenhum canal favorito. Em Ao Vivo, pressione OPTIONS no canal."
    end if
  else
    m.status.text = count.toStr() + " favoritos"
  end if
end sub

sub paintFilters()
  filtersFocused = m.filters.isInFocusChain()
  for i = 0 to 2
    focused = filtersFocused and i = m.filterIndex
    if focused then m.filterGlows[i].focusPercent = 1.0 else m.filterGlows[i].focusPercent = 0.0
    m.filterGlows[i].focused = focused
    if i = m.filterIndex
      m.filterBgs[i].color = "0xFFFFFFFF"
      m.filterLabels[i].color = "0x141414FF"
    else
      m.filterBgs[i].color = "0x252525FF"
      m.filterLabels[i].color = "0xFFFFFFFF"
    end if
  end for
end sub

sub onError(event as object)
  m.spinner.control = "stop"
  m.spinner.visible = false
  m.status.text = "Erro ao carregar favoritos: " + event.getData()
end sub

sub onSelected()
  index = m.items.itemSelected
  if index < 0 or m.items.content = invalid then return
  item = m.items.content.GetChild(index)
  if item = invalid then return
  if item.k = 4
    task = CreateObject("roSGNode", "ApiTask")
    task.url = m.api + "?a=live_item&id=" + item.id.toStr() + "&profile=" + m.scene.profileId
    task.observeField("result", "onLiveFavoriteResult")
    task.observeField("error", "onLiveFavoriteError")
    task.control = "RUN"
    return
  end if
  m.top.selected = {id: item.id, k: item.k, t: item.t}
end sub

sub onLiveFavoriteResult(event as object)
  item = event.getData()
  if item = invalid or item.streamUrl = invalid or item.streamUrl = "" then return
  m.top.selected = {id: item.id, k: 0, t: item.name, u: item.streamUrl, x: item.ext, h: item.headers, live: true}
end sub

sub onLiveFavoriteError(event as object)
  m.status.text = "Não foi possível abrir o canal: " + event.getData()
end sub

sub onItemFocused()
  focused = m.items.itemFocused
  if focused = 0 and m.items.isInFocusChain() then paintFilters()
end sub

sub focusContent()
  m.filters.setFocus(true)
  paintFilters()
end sub

function origin(url as string) as string
  marker = InStr(0, url, "//")
  if marker < 0 then return url
  marker += 2
  slash = InStr(marker, url, "/")
  if slash > 0 then return url.Left(slash - 1)
  return url
end function

function absImg(path) as string
  if path = invalid or path = "" then return ""
  if path.Left(4) = "http" then return path
  return m.base + path
end function

function onKeyEvent(key as string, press as boolean) as boolean
  if not press then return false
  key = LCase(key)
  if key = "back"
    m.scene.callFunc("focusTopBar")
    return true
  end if
  if m.filters.isInFocusChain()
    if key = "left" and m.filterIndex > 0
      m.filterIndex = m.filterIndex - 1
      renderFavorites()
      return true
    else if key = "right" and m.filterIndex < 2
      m.filterIndex = m.filterIndex + 1
      renderFavorites()
      return true
    else if key = "down"
      if m.items.content <> invalid and m.items.content.GetChildCount() > 0 then m.items.setFocus(true)
      paintFilters()
      return true
    else if key = "up"
      m.scene.callFunc("focusTopBar")
      paintFilters()
      return true
    end if
    return key = "ok" or key = "select"
  end if
  if key = "up"
    focused = m.items.itemFocused
    if focused = invalid or focused <= 0
      m.filters.setFocus(true)
      return true
    end if
  end if
  return false
end function
