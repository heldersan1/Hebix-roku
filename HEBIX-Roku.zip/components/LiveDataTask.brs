' Catálogo M3U vivo: requisições autenticadas e JSON fora da thread de renderização.
sub init()
  m.port = CreateObject("roMessagePort")
  m.top.observeField("command", m.port)
  m.top.functionName = "processCommands"
end sub

sub processCommands()
  m.api = m.top.api
  m.token = readToken()
  while m.top.keepRunning
    event = wait(0, m.port)
    if type(event) <> "roSGNodeEvent" or event.GetField() <> "command" then continue while
    command = event.GetData()
    if command = invalid then continue while

    if command.op = "categories" then
      loadCategories()
    else if command.op = "page" then
      loadPage(command.categoryId, command.after, command.favoriteIds, command.title)
    else if command.op = "search" then
      loadSearch(command.query, command.after)
    else if command.op = "item" then
      loadItem(command.id)
    end if
  end while
end sub

function readToken() as string
  section = CreateObject("roRegistrySection", "setup")
  token = section.Read("token")
  if token = invalid then return ""
  return token
end function

sub loadCategories()
  result = fetchJson(m.api + "?a=live_categories")
  if result = invalid or result.categories = invalid then
    send({kind: "error", message: "Não foi possível carregar as categorias"})
    return
  end if
  send({kind: "categories", total: result.total, items: result.categories})
end sub

sub loadPage(categoryId, after, favoriteIds, title)
  url = m.api + "?a=live_list&category=" + categoryId.toStr() + "&after=" + after.toStr() + "&n=30"
  if categoryId.toStr() = "-1" and favoriteIds <> invalid and favoriteIds.Count() > 0 then
    ids = []
    for each id in favoriteIds
      ids.Push(id.toStr())
    end for
    url = url + "&ids=" + ids.Join(",")
  end if
  result = fetchJson(url)
  if result = invalid or result.items = invalid then
    send({kind: "error", message: "Não foi possível carregar os canais", categoryId: categoryId})
    return
  end if
  send({kind: "page", categoryId: categoryId, categoryTitle: title, items: result.items,
    more: result.more, next: result.next})
end sub

sub loadSearch(query, after)
  if query = invalid or query.trim() = "" then
    send({kind: "search", items: [], more: false, next: invalid})
    return
  end if
  transfer = CreateObject("roUrlTransfer")
  url = m.api + "?a=live_search&q=" + transfer.Escape(query) + "&after=" + after.toStr() + "&n=30"
  result = fetchJson(url)
  if result = invalid or result.items = invalid then
    send({kind: "error", message: "Não foi possível pesquisar os canais"})
    return
  end if
  send({kind: "search", items: result.items, more: result.more, next: result.next})
end sub

sub loadItem(id)
  result = fetchJson(m.api + "?a=live_item&id=" + id.toStr())
  if result = invalid or result.streamUrl = invalid or result.streamUrl = "" then
    send({kind: "error", message: "Não foi possível carregar este canal"})
    return
  end if
  send({kind: "item", item: result})
end sub

function fetchJson(url as string)
  lastError = "Falha de conexão"
  for attempt = 1 to 2
    if not m.top.keepRunning then return invalid
    transfer = CreateObject("roUrlTransfer")
    transfer.SetUrl(url)
    transfer.EnableEncodings(true)
    transfer.SetCertificatesFile("common:/certs/ca-bundle.crt")
    transfer.InitClientCertificates()
    if m.token <> "" then transfer.AddHeader("X-Key", m.token)

    port = CreateObject("roMessagePort")
    transfer.SetMessagePort(port)
    if not transfer.AsyncGetToString() then
      lastError = "Não foi possível iniciar a requisição"
      exit for
    end if

    event = wait(8000, port)
    if not m.top.keepRunning
      transfer.AsyncCancel()
      return invalid
    end if
    if type(event) = "roUrlEvent" then
      code = event.GetResponseCode()
      if code = 200 then
        parsed = ParseJson(event.GetString())
        if parsed <> invalid then return parsed
        lastError = "Resposta JSON inválida"
        exit for
      end if
      if code > 0 then
        lastError = "HTTP " + code.toStr()
        exit for
      end if
      transfer.AsyncCancel()
    else
      transfer.AsyncCancel()
      lastError = "Tempo esgotado"
    end if
  end for
  print "[live-task] " + lastError
  return invalid
end function

sub send(data as object)
  m.top.chunk = data
end sub
