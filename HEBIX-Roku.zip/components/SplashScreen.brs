sub init()
  m.splashOverlay = m.top.findNode("splashOverlay")
  m.splashOverlay.setFocus(true)
  m.transitionTimer = m.top.findNode("transitionTimer")
  m.transitionTimer.observeField("fire", "onTimerFired")
  m.top.findNode("splashAnim").control = "start"
  m.transitionTimer.control = "start"
end sub

sub onTimerFired()
  parent = m.splashOverlay.getParent()
  if parent <> invalid then parent.removeChild(m.splashOverlay)
  m.splashOverlay = invalid
  m.transitionTimer = invalid

  stack = m.top.findNode("stack")
  if stack <> invalid and stack.getChildCount() > 0 then
    current = stack.getChild(stack.getChildCount() - 1)
    if current <> invalid then current.callFunc("focusContent")
  end if
end sub
