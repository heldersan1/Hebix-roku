' Reusable top navigation: icon menu aligned to the right.
sub init()
  m.icons = [
    m.top.findNode("nav0"),
    m.top.findNode("nav1"),
    m.top.findNode("nav2"),
    m.top.findNode("nav3"),
    m.top.findNode("nav4"),
    m.top.findNode("nav5"),
    m.top.findNode("nav6"),
    m.top.findNode("nav7")
  ]
  m.names = ["Início", "Filmes", "Séries", "Ao vivo", "Buscar", "Favoritos", "Ajustes", "Perfil"]
  m.sectionLabel = m.top.findNode("sectionLabel")
  m.underline = m.top.findNode("underline")
  m.focusPill = m.top.findNode("focusPill")
  m.focusGlow = m.top.findNode("focusGlow")
  m.focusTarget = m.top.findNode("focusTarget")
  m.logo = m.top.findNode("logo")
  m.menuFocused = false
  m.top.index = 0
  m.top.activated = -1
  m.focusTarget.observeField("focused", "onFocusTargetChanged")
  paint()
end sub

sub onFocusTargetChanged(event as object)
  m.menuFocused = event.getData()
  paint()
end sub

sub paint()
  index = m.top.index
  icon = m.icons[index]
  m.focusPill.translation = [icon.translation[0] - 4, 4]
  m.focusPill.visible = m.menuFocused
  m.focusGlow.translation = [icon.translation[0] - 4, 42]
  if m.menuFocused
    m.focusGlow.focusPercent = 1.0
  else
    m.focusGlow.focusPercent = 0.0
  end if
  m.focusGlow.focused = m.menuFocused
  for i = 0 to m.icons.Count() - 1
    if i = m.top.index then
      m.icons[i].blendColor = design().text
    else
      m.icons[i].blendColor = design().textMuted
    end if
  end for
  m.underline.translation = [m.icons[m.top.index].translation[0], 45]
  m.sectionLabel.text = m.names[m.top.index]
  m.logo.color = design().accent
end sub

sub focusMenu()
  m.menuFocused = true
  m.focusTarget.setFocus(true)
  paint()
end sub

sub unfocusMenu()
  m.menuFocused = false
  m.focusTarget.setFocus(false)
  paint()
end sub

sub move(delta)
  index = m.top.index + delta
  if index < 0 then index = m.icons.Count() - 1
  if index >= m.icons.Count() then index = 0
  m.top.index = index
  paint()
end sub

sub activate()
  m.top.activated = m.top.index
end sub

function onKeyEvent(key, press) as boolean
  if not press then return false
  key = LCase(key)
  if key = "left"
    move(-1)
    return true
  else if key = "right"
    move(1)
    return true
  else if key = "up"
    return true
  else if key = "ok" or key = "select"
    m.top.activated = m.top.index
    return true
  end if
  return false
end function
