' Gestão de fontes. Senhas trafegam no corpo POST e nunca são impressas.
sub init()
  m.scene=m.top.getScene() : m.api=m.scene.server
  m.status=m.top.findNode("status") : m.active=m.top.findNode("active") : m.sources=m.top.findNode("sources")
  m.actions=m.top.findNode("actions")
  m.tmdbLogo=m.top.findNode("tmdbLogo") : m.tmdbCredit=m.top.findNode("tmdbCredit")
  ' Acoes como RowList: previsivel no D-pad (Button em coluna nao era alcancavel).
  content=CreateObject("roSGNode","ContentNode") : arow=content.CreateChild("ContentNode")
  labels=["Listas","Celular","M3U","Xtream","Editar","Ativar/Desativar","Atualizar","Remover","Resetar Config."]
  icons=["pkg:/images/icon-list.png","pkg:/images/icon-phone.png","pkg:/images/icon-plus.png","pkg:/images/icon-plus.png","pkg:/images/icon-pencil.png","pkg:/images/icon-check.png","pkg:/images/icon-refresh.png","pkg:/images/icon-close.png","pkg:/images/icon-refresh.png"]
  for i=0 to labels.Count()-1
    arow.CreateChild("ContentNode").update({t:labels[i],i:icons[i]},true)
  end for
  m.actions.content=content
  m.actions.observeField("rowItemSelected","onActionSelected")
  m.sources.observeField("rowItemFocused","onSourceFocused") : m.sources.observeField("rowItemSelected","onSourceSelected")
  m.dlg=invalid : m.mode="" : m.values={} : m.selected=invalid : m.listMode="sources"
  m.focusTimer=m.top.findNode("focusTimer") : m.focusTimer.observeField("fire","onFocusTimer")
  loadSources()
end sub
sub loadSources()
  m.status.text="Carregando fontes..."
  t=CreateObject("roSGNode","ApiTask") : t.url=m.api+"?a=sources"
  t.observeField("result","onSources") : t.observeField("error","onError") : t.control="RUN"
end sub
sub onSources(ev)
  r=ev.getData()
  if r=invalid or r.sources=invalid then
    fail("Resposta inválida do servidor") : return
  end if
  tmdbEnabled = false
  if r.DoesExist("tmdb_enabled") and r.tmdb_enabled = true then tmdbEnabled = true
  m.tmdbLogo.visible = tmdbEnabled
  m.tmdbCredit.visible = tmdbEnabled
  m.listMode="sources"
  content=CreateObject("roSGNode","ContentNode") : activeNames=[]
  row=content.CreateChild("ContentNode")
  for each s in r.sources
    state="inativa"
    if s.active then
      state="ATIVA" : activeNames.push(s.label)
    end if
    fixed = s.fixed = 1
    label = s.label
    if fixed then label = label + "  (padrão)"
    row.CreateChild("ContentNode").update({id:s.id,t:label,m:state+" · "+s.type+" · "+s.items.toStr()+" itens",active:s.active,fixed:fixed},true)
  end for
  m.sources.content=content : m.active.text="Listas ativas: "+activeNames.join(", ")
  m.status.text="Escolha a lista e use Ativar/Desativar. Listas traz listas prontas."
  if content.GetChildCount()>0 then m.sources.setFocus(true)
end sub
sub loadPresets()
  m.status.text="Carregando listas prontas..."
  t=CreateObject("roSGNode","ApiTask") : t.url=m.api+"?a=presets"
  t.observeField("result","onPresets") : t.observeField("error","onError") : t.control="RUN"
end sub
sub onPresets(ev)
  r=ev.getData()
  if r=invalid or r.presets=invalid then
    fail("Resposta inválida do servidor") : return
  end if
  content=CreateObject("roSGNode","ContentNode") : row=content.CreateChild("ContentNode")
  for each p in r.presets
    row.CreateChild("ContentNode").update({id:p.id,t:p.label,m:p.desc,u:p.url},true)
  end for
  m.listMode="presets"
  m.sources.content=content
  m.status.text="Escolha uma lista pronta: ela é adicionada e ativada na hora."
  if row.GetChildCount()>0 then m.sources.setFocus(true)
end sub
sub onSourceSelected()
  if m.selected=invalid then
    return
  end if
  if m.listMode="presets" then
    addPreset()
  else
    post("source_activate","")
  end if
end sub
sub addPreset()
  m.status.text="Adicionando "+m.selected.t+"..."
  body="name="+enc(m.selected.t)+"&type=url&url="+enc(m.selected.u)
  t=CreateObject("roSGNode","ApiTask") : t.url=m.api+"?a=source_add" : t.postData=body
  t.observeField("result","onPresetAdded") : t.observeField("error","onError") : t.control="RUN"
end sub
sub onPresetAdded(ev)
  r=ev.getData()
  if r=invalid or r.ok=invalid or r.id=invalid then
    fail("Não foi possível adicionar a lista") : return
  end if
  m.status.text="Ativando a lista..."
  m.newSourceId=r.id
  t=CreateObject("roSGNode","ApiTask") : t.url=m.api+"?a=source_activate" : t.postData="id="+r.id.toStr()
  t.observeField("result","onPresetActivated") : t.observeField("error","onError") : t.control="RUN"
end sub
sub onPresetActivated(ev)
  ' Lista nova chega vazia: pede o download em segundo plano e volta para as fontes.
  t=CreateObject("roSGNode","ApiTask") : t.url=m.api+"?a=source_sync" : t.postData="id="+m.newSourceId.toStr()
  t.observeField("result","onPost") : t.observeField("error","onError") : t.control="RUN"
  m.status.text="Lista ativada. Baixando o conteúdo em segundo plano..."
end sub
sub onSourceFocused()
  f=m.sources.rowItemFocused
  if f=invalid or f.Count()<2 then return
  row=m.sources.content.GetChild(f[0])
  if row=invalid then return
  m.selected=row.GetChild(f[1])
end sub
sub prompt(title,value,nextMode)
  d=CreateObject("roSGNode","StandardKeyboardDialog") : d.title=title : d.text=value : d.buttons=["Continuar"]
  d.observeField("buttonSelected","onValue") : d.observeField("wasClosed","onClosed") : m.scene.dialog=d : m.dlg=d : m.mode=nextMode
  ' Senha mascarada nos campos de senha; texto comum nos demais.
  if nextMode="addPass" or nextMode="editPass" then d.keyboardDomain="password" else d.keyboardDomain="generic"
  ' Foco no diálogo e no teclado interno: sem isso o TextEditBox ignora as teclas.
  d.setFocus(true)
  if d.textEditBox<>invalid then d.textEditBox.setFocus(true)
  ' O no teclado interno pode ainda nao existir no instante da criacao:
  ' o Timer refoca o dialogo depois que ele e exibido.
  m.focusTimer.control="start"
end sub
sub onFocusTimer()
  if m.dlg=invalid then return
  m.dlg.setFocus(true)
  if m.dlg.textEditBox<>invalid then m.dlg.textEditBox.setFocus(true)
end sub
sub onValue(ev)
  advance()
end sub
sub onClosed(ev)
  ' wasClosed e buttonSelected chegam em ordem variavel. Se o botao nao disparou
  ' mas havia texto digitado, o campo e confirmado assim mesmo.
  if m.dlg=invalid then return
  if m.dlg.text.trim()="" then
    m.dlg=invalid : m.mode="" : m.scene.dialog=invalid
    return
  end if
  advance()
end sub
sub advance()
  if m.dlg=invalid then return
  value=m.dlg.text.trim() : mode=m.mode
  m.dlg=invalid : m.mode="" : m.scene.dialog=invalid
  if mode="addName" then
    m.values.name=value : prompt("Nome da fonte",value,"addUrl")
  else if mode="addUrl" then
    m.values.url=value : post("source_add","url")
  else if mode="addHost" then
    m.values.url=value : prompt("Usuário","","addUser")
  else if mode="addUser" then
    m.values.username=value : prompt("Senha","","addPass")
  else if mode="addPass" then
    m.values.password=value : post("source_add","xtream")
  else if mode="editName" then
    m.values.name=value : prompt("URL completa da lista (reobrigatória)","","editUrl")
  else if mode="editUrl" then
    m.values.url=value : post("source_update","url")
  else if mode="editUser" then
    m.values.username=value : prompt("Nova senha (deixe vazio para manter)","","editPass")
  else if mode="editPass" then
    m.values.password=value : post("source_update","xtream")
  end if
end sub
sub onActionSelected(ev)
  f=ev.getData()
  if f=invalid or f.Count()<2 then return
  onAction(f[1])
end sub
sub onAction(index)
  if index=0 then
    loadPresets()
  else if index=1 then
    m.scene.callFunc("openPair")
  else if index=2 then
    m.values={} : prompt("Nome da fonte","","addName")
  else if index=3 then
    m.values={} : prompt("Host Xtream (http://host:porta)","","addHost")
  else if index=4 then
    if m.selected=invalid then
      fail("Selecione uma lista") : return
    end if
    m.values={id:m.selected.id,name:m.selected.t}
    if m.selected.m<>invalid and m.selected.m.Contains("xtream") then
      prompt("Usuário (reobrigatório)","","editUser")
    else
      prompt("Nome da fonte",m.selected.t,"editName")
    end if
  else if index=5 then
    if m.selected=invalid then
      fail("Selecione uma lista") : return
    end if
    if m.selected.active then
      post("source_deactivate","")
    else
      post("source_activate","")
    end if
  else if index=6 then
    if m.selected=invalid then
      fail("Selecione uma lista") : return
    end if
    post("source_sync","")
  else if index=7 then
    if m.selected=invalid then
      fail("Selecione uma lista") : return
    end if
    if m.selected.fixed = true then
      fail("A lista padrão não pode ser removida (ela pode ser alterada).") : return
    end if
    post("source_remove","")
  else if index=8 then
    resetConfig()
  end if
end sub

sub resetConfig()
  sec = CreateObject("roRegistrySection", "setup")
  sec.Delete("server")
  sec.Delete("token")
  sec.Flush()
  m.status.text = "Configuração resetada. Reinicie o app (Home + launch) para configurar novo servidor."
  m.top.changed = true
end sub

sub post(action,kind)
  if kind="" then
    body="id="+m.selected.id.toStr()
  else
    body="name="+enc(m.values.name)+"&type="+kind+"&url="+enc(m.values.url)
    if kind="xtream" then body=body+"&username="+enc(m.values.username)+"&password="+enc(m.values.password)
    if action="source_update" then body=body+"&id="+m.selected.id.toStr()
  end if
  m.values={} : m.status.text="Processando..."
  t=CreateObject("roSGNode","ApiTask") : t.url=m.api+"?a="+action : t.postData=body
  if action="source_sync" then t.timeoutMs=30000
  t.observeField("result","onPost") : t.observeField("error","onError") : t.control="RUN"
end sub

sub onPost(ev)
  r=ev.getData()
  if r=invalid or r.ok=invalid then
    fail("A operação não foi concluída") : return
  end if
  m.status.text="Concluído. Atualizando fontes..." : m.top.changed=true : loadSources()
end sub
sub onError(ev)
  fail("Falha: "+ev.getData())
end sub
sub fail(message)
  m.status.text=message+" - tente novamente"
end sub
function onKeyEvent(key,press) as boolean
  if not press then return false
  key=LCase(key)
  if m.sources.isInFocusChain() then
    if key="up" then
      m.scene.callFunc("focusTopBar") : return true
    else if key="down" then
      m.actions.setFocus(true) : return true
    end if
    return false
  end if
  if m.actions.isInFocusChain() then
    if key="up" then
      m.sources.setFocus(true) : return true
    end if
    ' left/right/ok ficam com o RowList (ele dispara rowItemSelected).
    return false
  end if
  return false
end function
sub focusContent()
  ' Foca a lista mesmo antes do conteudo chegar: sem isso o foco fica na TopBar
  ' e a tela de Ajustes nao recebe nenhuma tecla.
  m.sources.setFocus(true)
end sub
