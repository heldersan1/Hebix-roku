' M3U catalog UI. Content comes only from live_* API endpoints; MarkupGrid windows cards.
sub init()
  m.scene = m.top.getScene()
  m.api = m.scene.server
  m.base = liveImageOrigin(m.api)
  m.categories = m.top.findNode("categoryList")
  m.grid = m.top.findNode("channelGrid")
  m.heroLogo = m.top.findNode("heroLogo")
  m.heroName = m.top.findNode("heroName")
  m.heroCategory = m.top.findNode("heroCategory")
  m.heroState = m.top.findNode("heroState")
  m.heading = m.top.findNode("categoryHeading")
  m.status = m.top.findNode("status")
  m.empty = m.top.findNode("empty")
  m.spinner = m.top.findNode("liveSpinner")
  m.searchBar = m.top.findNode("searchBar")
  m.favoriteAction = m.top.findNode("favoriteAction")
  m.favoriteActionBg = m.top.findNode("favoriteActionBg")
  m.favoriteActionLabel = m.top.findNode("favoriteActionLabel")
  m.searchFocus = m.top.findNode("searchFocus")
  m.searchFocusGlow = m.top.findNode("searchFocusGlow")
  m.favoriteActionGlow = m.top.findNode("favoriteActionGlow")
  m.searchText = m.top.findNode("searchText")
  m.categoryContent = CreateObject("roSGNode", "ContentNode")
  m.gridContent = CreateObject("roSGNode", "ContentNode")
  m.currentItems = []
  m.favoriteIds = loadFavoriteIds()
  syncLegacyFavorites()
  m.query = ""
  m.searchDialog = invalid
  m.currentCategory = invalid
  m.currentTitle = ""
  m.after = 0
  m.more = false
  m.loading = false
  m.searchMode = false
  m.playerState = "idle"
  m.selectedChannel = invalid
  m.categories.observeField("itemSelected", "onCategorySelected")
  m.grid.observeField("itemFocused", "onGridFocused")
  m.grid.observeField("itemSelected", "onGridSelected")
  m.top.observeField("focusedChild", "onFocusChanged")
  m.searchBar.observeField("focusedChild", "onSearchFocus")
  m.favoriteAction.observeField("focusedChild", "onFavoriteActionFocus")

  m.dataTask = CreateObject("roSGNode", "LiveDataTask")
  m.dataTask.api = m.api
  m.dataTask.keepRunning = true
  m.dataTask.observeField("chunk", "onData")
  m.top.appendChild(m.dataTask)
  m.dataTask.command = {op: "categories"}
  m.dataTask.control = "RUN"
  setLoading(true)
end sub

function liveImageOrigin(url as string) as string
  marker = InStr(0, url, "//")
  if marker < 1 then return url
  slash = InStr(marker + 2, url, "/")
  if slash > 0 then return url.Left(slash - 1)
  return url
end function

function liveImageUrl(path as string) as string
  if path = invalid or path = "" then return ""
  if Left(path, 4) = "http" then return path
  return m.base + path
end function

function loadFavoriteIds() as object
  profile = m.scene.profileId
  if profile = invalid or profile = "" then profile = "default"
  section = CreateObject("roRegistrySection", "live_favorites_" + profile)
  raw = section.Read("ids")
  ids = []
  if raw <> invalid and raw <> ""
    for each value in raw.Split(",")
      id = Val(value)
      if id > 0 then ids.Push(id)
    end for
  end if
  return ids
end function

sub saveFavoriteIds()
  values = []
  for each id in m.favoriteIds
    values.Push(id.toStr())
  end for
  profile = m.scene.profileId
  if profile = invalid or profile = "" then profile = "default"
  section = CreateObject("roRegistrySection", "live_favorites_" + profile)
  section.Write("ids", values.Join(","))
  section.Flush()
end sub

sub syncLegacyFavorites()
  if m.favoriteIds.Count() = 0 then return
  ids = []
  for each id in m.favoriteIds
    ids.Push(id.toStr())
  end for
  task = CreateObject("roSGNode", "ApiTask")
  task.url = m.api + "?a=live_fav&profile=" + m.scene.profileId
  task.postData = "sync=1&ids=" + ids.Join(",")
  task.observeField("result", "onLegacyFavoritesSynced")
  task.observeField("error", "onLegacyFavoriteSyncError")
  m.legacyFavoriteTask = task
  m.top.appendChild(task)
  task.control = "RUN"
end sub

sub onLegacyFavoritesSynced(event as object)
  if m.legacyFavoriteTask <> invalid
    m.top.removeChild(m.legacyFavoriteTask)
    m.legacyFavoriteTask = invalid
  end if
end sub

sub onLegacyFavoriteSyncError(event as object)
  if m.legacyFavoriteTask <> invalid
    m.top.removeChild(m.legacyFavoriteTask)
    m.legacyFavoriteTask = invalid
  end if
  m.status.text = "Não foi possível sincronizar favoritos antigos."
end sub

sub saveServerFavorite(id as integer, isFavorite as boolean)
  if m.favoriteTask <> invalid then return
  task = CreateObject("roSGNode", "ApiTask")
  task.url = m.api + "?a=live_fav&profile=" + m.scene.profileId
  fav = "0"
  if isFavorite then fav = "1"
  task.postData = "id=" + id.toStr() + "&fav=" + fav
  task.observeField("result", "onFavoriteSaved")
  task.observeField("error", "onFavoriteSaveError")
  m.favoriteRequestedId = id
  m.favoriteRequestedState = isFavorite
  m.favoriteTask = task
  m.top.appendChild(task)
  m.status.text = "Salvando favorito..."
  task.control = "RUN"
end sub

sub finishFavoriteTask()
  if m.favoriteTask <> invalid
    m.top.removeChild(m.favoriteTask)
    m.favoriteTask = invalid
  end if
end sub

sub onFavoriteSaved(event as object)
  result = event.getData()
  id = m.favoriteRequestedId
  finishFavoriteTask()
  if result = invalid or result.fav = invalid
    m.status.text = "Não foi possível confirmar o favorito."
    return
  end if
  index = -1
  for i = 0 to m.favoriteIds.Count() - 1
    if m.favoriteIds[i] = id then index = i
  end for
  if result.fav = 1 and index < 0
    m.favoriteIds.Push(id)
  else if result.fav = 0 and index >= 0
    m.favoriteIds.Delete(index)
  end if
  saveFavoriteIds()
  for i = 0 to m.currentItems.Count() - 1
    if m.currentItems[i].id = id
      m.gridContent.GetChild(i).isFavorite = result.fav = 1
      exit for
    end if
  end for
  if m.categoryContent.GetChildCount() > 1 then m.categoryContent.GetChild(1).count = m.favoriteIds.Count()
  paintFavoriteAction()
  if m.currentCategory <> invalid and m.currentCategory.toStr() = "-1"
    selectCategory(-1, "Favoritos")
  else if result.fav = 1
    m.status.text = "Canal adicionado aos Favoritos."
  else
    m.status.text = "Canal removido dos Favoritos."
  end if
end sub

sub onFavoriteSaveError(event as object)
  finishFavoriteTask()
  m.status.text = "Falha ao salvar favorito: " + event.getData()
end sub

sub onFavoriteActionFocus()
  paintFavoriteAction()
end sub

sub paintFavoriteAction()
  index = focusedChannelIndex()
  isFavorite = false
  if index >= 0 and index < m.currentItems.Count()
    isFavorite = containsFavorite(m.currentItems[index].id)
  end if
  if isFavorite then m.favoriteActionLabel.text = "REMOVER FAVORITO" else m.favoriteActionLabel.text = "ADICIONAR FAVORITO"
  focused = m.favoriteAction.isInFocusChain()
  if focused then m.favoriteActionGlow.focusPercent = 1.0 else m.favoriteActionGlow.focusPercent = 0.0
  m.favoriteActionGlow.focused = focused
  if m.favoriteAction.isInFocusChain()
    m.favoriteActionBg.color = "0xFFC300FF"
    m.favoriteActionLabel.color = "0x141414FF"
  else
    m.favoriteActionBg.color = "0x252525FF"
    m.favoriteActionLabel.color = "0xFFFFFFFF"
  end if
end sub

function focusedChannelIndex() as integer
  focused = m.grid.itemFocused
  if focused = invalid then return -1
  if type(focused) = "roArray"
    if focused.Count() < 2 then return -1
    return focused[0] * 5 + focused[1]
  end if
  return focused
end function

sub setLoading(active as boolean)
  m.loading = active
  m.spinner.visible = active
  if active
    m.spinner.control = "start"
    m.status.text = "Carregando canais..."
  else
    m.spinner.control = "stop"
  end if
end sub

sub onScreenHidden()
  if m.dataTask <> invalid
    m.dataTask.keepRunning = false
    m.dataTask.control = "STOP"
  end if
end sub

sub reloadCatalog()
  m.categoryContent = CreateObject("roSGNode", "ContentNode")
  m.gridContent = CreateObject("roSGNode", "ContentNode")
  m.currentItems = []
  m.categories.content = m.categoryContent
  m.grid.content = m.gridContent
  m.currentCategory = invalid
  m.query = ""
  m.searchText.text = "Buscar canais"
  m.heading.text = ""
  m.empty.visible = false
  setLoading(true)
  m.dataTask.command = {op: "categories"}
end sub

sub focusContent()
  if m.grid.content <> invalid and m.grid.content.GetChildCount() > 0
    m.grid.setFocus(true)
  else if m.categories.content <> invalid and m.categories.content.GetChildCount() > 0
    m.categories.setFocus(true)
  else
    m.searchBar.setFocus(true)
  end if
end sub

sub onFocusChanged()
  paintFavoriteAction()
  onSearchFocus()
  if m.top.isInFocusChain() and not m.grid.isInFocusChain() and not m.categories.isInFocusChain() and not m.searchBar.isInFocusChain()
    focusContent()
  end if
end sub

sub onSearchFocus()
  focused = m.searchBar.isInFocusChain()
  m.searchFocus.visible = focused
  if focused then m.searchFocusGlow.focusPercent = 1.0 else m.searchFocusGlow.focusPercent = 0.0
  m.searchFocusGlow.focused = focused
end sub

sub onData(event as object)
  data = event.getData()
  if data = invalid then return
  if data.kind = "error"
    setLoading(false)
    m.status.text = data.message
    return
  end if
  if data.kind = "categories"
    buildCategories(data)
    return
  end if
  if data.kind = "page" or data.kind = "search"
    appendItems(data.items)
    m.more = data.more
    if data.next <> invalid then m.after = data.next else m.after = 0
    setLoading(false)
    if m.gridContent.GetChildCount() = 0
      m.empty.text = "Nenhum canal encontrado"
      m.empty.visible = true
      m.status.text = ""
    else
      m.empty.visible = false
      m.status.text = m.gridContent.GetChildCount().toStr() + " canais"
    end if
    return
  end if
  if data.kind = "item"
    channel = data.item
    if channel = invalid or channel.streamUrl = invalid or channel.streamUrl = ""
      setLoading(false)
      m.status.text = "Não foi possível carregar este canal"
      return
    end if
    channel.k = 0
    channel.t = channel.name
    channel.u = channel.streamUrl
    channel.x = channel.ext
    channel.h = channel.headers
    channel.live = true
    setLoading(false)
    m.status.text = ""
    m.top.selected = channel
  end if
end sub

sub buildCategories(data as object)
  categories = data.items
  if categories = invalid then categories = []
  all = m.categoryContent.CreateChild("ContentNode")
  all.update({id: 0, title: "Todos os Canais", count: data.total}, true)
  fav = m.categoryContent.CreateChild("ContentNode")
  fav.update({id: -1, title: "Favoritos", count: m.favoriteIds.Count()}, true)
  for each entry in categories
    row = m.categoryContent.CreateChild("ContentNode")
    row.update({id: entry.id, title: entry.name, count: entry.count}, true)
  end for
  m.categories.content = m.categoryContent
  if m.categoryContent.GetChildCount() > 0 then m.categories.jumpToItem = 0
  selectCategory(0, "Todos os Canais")
  if not m.grid.isInFocusChain() and not m.categories.isInFocusChain() then m.categories.setFocus(true)
end sub

sub onCategorySelected(event as object)
  index = event.getData()
  if index = invalid or index < 0 or index >= m.categoryContent.GetChildCount() then return
  item = m.categoryContent.GetChild(index)
  selectCategory(item.id, item.title)
  m.grid.setFocus(true)
end sub

sub selectCategory(id, title as string)
  m.currentCategory = id
  m.currentTitle = title
  m.heading.text = liveCategoryLabel(title)
  m.searchMode = false
  m.after = 0
  m.more = false
  m.gridContent = CreateObject("roSGNode", "ContentNode")
  m.currentItems = []
  m.grid.content = m.gridContent
  m.empty.visible = false
  setLoading(true)
  m.dataTask.command = {op: "page", categoryId: id, after: 0, favoriteIds: m.favoriteIds, title: title}
end sub

sub appendItems(items)
  if items = invalid then return
  for each item in items
    content = m.gridContent.CreateChild("ContentNode")
    logo = liveImageUrl(item.logo)
    isFavorite = containsFavorite(item.id)
    content.update({id: item.id, name: item.name, tvgId: item.tvgId, tvgName: item.tvgName,
      groupTitle: item.groupTitle, logo: logo, isFavorite: isFavorite, isLive: false}, true)
    m.currentItems.Push(item)
  end for
  m.grid.content = m.gridContent
  if m.heroName.text = "" and m.currentItems.Count() > 0 then renderHeroForIndex(0)
  if m.grid.isInFocusChain() then renderHeroForIndex(m.grid.itemFocused)
end sub

function containsFavorite(id) as boolean
  for each favoriteId in m.favoriteIds
    if favoriteId = id then return true
  end for
  return false
end function

sub onGridFocused(event as object)
  index = event.getData()
  if index = invalid then return
  ' MarkupGrid reports a flat item index. RowList compatibility covers older firmware.
  if type(index) = "roArray"
    if index.Count() < 2 then return
    index = index[0] * 5 + index[1]
  end if
  renderHeroForIndex(index)
  paintFavoriteAction()
  if m.more and not m.loading and index >= m.currentItems.Count() - 8 then
    setLoading(true)
    if m.searchMode
      m.dataTask.command = {op: "search", query: m.query, after: m.after}
    else
      m.dataTask.command = {op: "page", categoryId: m.currentCategory, after: m.after,
        favoriteIds: m.favoriteIds, title: m.currentTitle}
    end if
  end if
end sub

sub renderHeroForIndex(index)
  if index = invalid then return
  if type(index) = "roArray"
    if index.Count() < 2 then return
    index = index[0] * 5 + index[1]
  end if
  if index < 0 or index >= m.currentItems.Count() then return
  item = m.currentItems[index]
  m.heroName.text = cleanLiveLabel(item.name)
  m.heroCategory.text = liveCategoryLabel(item.groupTitle)
  m.heroState.text = liveStateLabel(m.playerState)
  m.heroState.color = liveStateColor(m.playerState)
  if item.logo <> invalid and item.logo <> ""
    m.heroLogo.uri = fitImg(liveImageUrl(item.logo), 380, 252)
    m.heroLogo.visible = true
  else
    m.heroLogo.uri = ""
    m.heroLogo.visible = false
  end if
  paintFavoriteAction()
end sub

function liveStateLabel(state as string) as string
  if state = "playing" then return "● AO VIVO"
  if state = "loading" or state = "buffering" then return "CARREGANDO..."
  if state = "error" then return "INDISPONÍVEL"
  return "PRONTO PARA REPRODUZIR"
end function

function liveStateColor(state as string) as string
  if state = "playing" then return "0x00D66BFF"
  if state = "error" then return "0xE50914FF"
  if state = "loading" or state = "buffering" then return "0xF5C542FF"
  return "0xA0A0A0FF"
end function

sub setPlaybackState(state as string)
  m.playerState = state
  if m.selectedChannel <> invalid
    isLive = false
    if state = "playing" then isLive = true
    m.selectedChannel.isLive = isLive
    m.heroState.text = liveStateLabel(state)
    m.heroState.color = liveStateColor(state)
    for index = 0 to m.currentItems.Count() - 1
      if m.currentItems[index].id = m.selectedChannel.id
        m.gridContent.GetChild(index).isLive = isLive
      end if
    end for
  end if
end sub

sub onGridSelected(event as object)
  index = event.getData()
  if index = invalid then return
  if type(index) = "roArray"
    if index.Count() < 2 then return
    index = index[0] * 5 + index[1]
  end if
  if index < 0 or index >= m.currentItems.Count() then return
  item = m.currentItems[index]
  m.selectedChannel = item
  item.isLive = false
  m.heroState.text = "CARREGANDO..."
  m.heroState.color = "0xF5C542FF"
  setLoading(false)
  m.status.text = ""
  m.dataTask.command = {op: "item", id: item.id}
end sub

sub toggleFavorite()
  focused = focusedChannelIndex()
  if focused = invalid or focused < 0 or focused >= m.currentItems.Count() then return
  item = m.currentItems[focused]
  if m.favoriteTask <> invalid then return
  saveServerFavorite(item.id, not containsFavorite(item.id))
end sub

sub requestSearch()
  if m.searchDialog <> invalid then return
  dialog = CreateObject("roSGNode", "StandardKeyboardDialog")
  dialog.title = "Buscar canais"
  dialog.message = ["Nome, metadado, ID ou categoria"]
  dialog.text = m.query
  dialog.buttons = ["Buscar"]
  dialog.keyboardDomain = "generic"
  dialog.observeField("text", "onSearchText")
  dialog.observeField("buttonSelected", "onSearchClosed")
  dialog.observeField("wasClosed", "onSearchClosed")
  m.searchDialog = dialog
  m.scene.dialog = dialog
  dialog.setFocus(true)
  if dialog.textEditBox <> invalid then dialog.textEditBox.setFocus(true)
end sub

sub onSearchText(event as object)
  value = event.getData()
  if value = invalid then return
  m.query = value.trim()
end sub

sub onSearchClosed(event as object)
  if m.searchDialog = invalid then return
  m.scene.dialog = invalid
  m.searchDialog = invalid
  m.searchText.text = m.query
  m.searchMode = m.query <> ""
  m.after = 0
  m.more = false
  m.gridContent = CreateObject("roSGNode", "ContentNode")
  m.currentItems = []
  m.grid.content = m.gridContent
  m.heading.text = "Resultados da busca"
  setLoading(true)
  if m.searchMode
    m.dataTask.command = {op: "search", query: m.query, after: 0}
  else
    selectCategory(m.currentCategory, m.currentTitle)
  end if
  m.grid.setFocus(true)
end sub

function onKeyEvent(key as string, press as boolean) as boolean
  if not press then return false
  key = LCase(key)
  if key = "red" and (m.grid.isInFocusChain() or m.favoriteAction.isInFocusChain())
    toggleFavorite()
    return true
  end if
  if m.favoriteAction.isInFocusChain()
    if key = "ok" or key = "select"
      toggleFavorite()
      return true
    else if key = "down"
      m.grid.setFocus(true)
      return true
    else if key = "up"
      m.searchBar.setFocus(true)
      return true
    else if key = "left"
      m.categories.setFocus(true)
      return true
    end if
    return true
  end if
  if m.searchBar.isInFocusChain()
    if key = "ok" or key = "select"
      requestSearch()
      return true
    else if key = "down"
      m.categories.setFocus(true)
      return true
    else if key = "up"
      m.scene.callFunc("focusTopBar")
      return true
    end if
  end if
  if (key = "options" or key = "info") and m.grid.isInFocusChain()
    toggleFavorite()
    return true
  end if
  if key = "left" and m.grid.isInFocusChain()
    m.categories.setFocus(true)
    return true
  end if
  if key = "up" and m.grid.isInFocusChain()
    focused = focusedChannelIndex()
    if focused >= 0 and focused < 5
      m.favoriteAction.setFocus(true)
      return true
    end if
  end if
  if key = "right" and m.categories.isInFocusChain()
    m.grid.setFocus(true)
    return true
  end if
  if key = "up" and m.categories.isInFocusChain()
    focused = m.categories.itemFocused
    if focused = 0 then m.searchBar.setFocus(true)
    return true
  end if
  if key = "back"
    if m.searchDialog <> invalid
      m.scene.dialog = invalid
      m.searchDialog = invalid
      m.grid.setFocus(true)
      return true
    end if
    m.scene.callFunc("focusTopBar")
    return true
  end if
  return false
end function
