' Detalhes de filme, série e canal. Consome ?a=item e ?a=show reais.
' Navegação por ÍNDICE: Group com focusable não recebe tecla no Roku OS 16,
' então o foco fica no próprio componente (Details focusable="true") e os
' botões são pintados à mão em paintButtons().
sub init()
  m.scene = m.top.getScene()
  m.base = origin(m.scene.server)
  m.api = m.scene.server
  m.title = m.top.findNode("title")
  m.meta = m.top.findNode("meta")
  m.description = m.top.findNode("description")
  m.poster = m.top.findNode("poster")
  m.backdrop = m.top.findNode("backdrop")
  m.genres = m.top.findNode("genres")
  m.episodes = m.top.findNode("episodes")
  m.episodesLabel = m.top.findNode("episodesLabel")
  m.cast = m.top.findNode("cast")
  m.playBg = m.top.findNode("playBg")
  m.playLabel = m.top.findNode("playLabel")
  m.favBg = m.top.findNode("favBg")
  m.favLabel = m.top.findNode("favLabel")
  m.infoBg = m.top.findNode("infoBg")
  m.infoLabel = m.top.findNode("infoLabel")
  m.playIcon = m.top.findNode("playIcon")
  m.favIcon = m.top.findNode("favIcon")
  m.infoIcon = m.top.findNode("infoIcon")
  m.buttonGlows = [m.top.findNode("playGlow"), m.top.findNode("favGlow"), m.top.findNode("infoGlow")]
  m.episodes.observeField("rowItemSelected", "onEpisodeSelected")
  m.playUrl = ""
  m.sel = 0
  m.expanded = false
  m.top.observeField("itemId", "onItemId")
  m.focusTimer = m.top.findNode("focusTimer")
  m.focusTimer.observeField("fire", "onFocusTimer")
  m.focusTimer.control = "start"
end sub

sub onItemId(ev)
  m.requested = true
  m.sel = 0
  m.backdrop.uri = "pkg:/images/hero-gradient.png"
  m.genres.text = ""
  m.description.text = ""
  m.cast.text = ""
  if m.top.contentKind = 2 then loadShow() else loadItem()
end sub

sub setBackdrop(b, p)
  uri = ""
  if b <> invalid and b <> "" then uri = absImg(b)
  if uri = "" then uri = "pkg:/images/hero-gradient.png"
  if Left(uri, 4) = "http" then uri = fitImg(uri, 1280, 672)
  m.backdrop.uri = uri
end sub

function origin(url) as string
  p = InStr(0, url, "//")
  if p < 0 then return url
  p += 2
  s = InStr(p, url, "/")
  if s > 0 then return url.Left(s - 1)
  return url
end function

function absImg(path) as string
  if path = invalid or path = "" then return ""
  if path.Left(4) = "http" then return path
  return m.base + path
end function

sub request(path, successName, errorName)
  t = CreateObject("roSGNode", "ApiTask")
  separator = "&"
  if InStr(0, path, "?") = 0 then separator = "?"
  t.url = m.api + path + separator + "profile=" + m.scene.profileId
  t.observeField("result", successName)
  t.observeField("error", errorName)
  t.control = "RUN"
end sub

' Pinta os três botões: o selecionado fica claro, os demais ficam escuros.
function pickDark(on as boolean) as string
  if on then return "-dark"
  return ""
end function

function pickColor(on as boolean) as string
  if on then return "0xFFFFFFFF"
  return "0x2A2A2AFF"
end function

function pickText(on as boolean) as string
  if on then return "0x141414FF"
  return "0xFFFFFFFF"
end function

sub paintButtons()
  if m.playBg = invalid or m.playLabel = invalid or m.favBg = invalid or m.favLabel = invalid or m.infoBg = invalid or m.infoLabel = invalid then
    return
  end if
  m.playIcon.uri = "pkg:/images/icon-play" + pickDark(m.sel = 0) + ".png"
  m.favIcon.uri = "pkg:/images/icon-heart" + pickDark(m.sel = 1) + ".png"
  m.infoIcon.uri = "pkg:/images/icon-info" + pickDark(m.sel = 2) + ".png"
  m.playBg.color = pickColor(m.sel = 0) : m.playLabel.color = pickText(m.sel = 0)
  m.favBg.color = pickColor(m.sel = 1) : m.favLabel.color = pickText(m.sel = 1)
  m.infoBg.color = pickColor(m.sel = 2) : m.infoLabel.color = pickText(m.sel = 2)
  for i = 0 to 2
    selected = i = m.sel
    if selected then m.buttonGlows[i].focusPercent = 1.0 else m.buttonGlows[i].focusPercent = 0.0
    m.buttonGlows[i].focused = selected
  end for
end sub

sub loadItem()
  request("?a=item&kind=" + m.top.contentKind.toStr() + "&id=" + m.top.itemId.toStr(), "onItemResult", "onError")
end sub

sub onItemResult(ev)
  r = ev.getData()
  if r = invalid then
    m.title.text = "Não foi possível carregar"
    return
  end if
  m.title.text = r.t
  meta = mediaTypeName(m.top.contentKind)
  if m.top.contentKind = 1 and r.y > 0 then meta = r.y.toStr() + " · " + meta
  if r.g <> invalid and r.g <> "" then meta = meta + " · " + r.g.toStr()
  m.meta.text = meta
  m.description.text = ""
  if r.o <> invalid and r.o <> "" then m.description.text = r.o
  setCast(r.c)
  if r.p <> invalid then m.poster.uri = fitImg(absImg(r.p), 240, 360) else m.poster.uri = "pkg:/images/no-poster.png"
  setBackdrop(r.b, r.p)
  if r.g <> invalid and r.g <> "" then
    m.genres.text = r.g.toStr()
  else if m.top.contentKind = 0 then
    m.genres.text = "Ao vivo"
  end if
  if m.top.contentKind = 0 then
    if m.description.text = "" then m.description.text = "Transmissão ao vivo de " + r.t + "."
    request("?a=epg&id=" + m.top.itemId.toStr(), "onLiveEpg", "onError")
  else if m.description.text = "" then
    m.description.text = "Sinopse não disponível para este título."
  end if
  m.episodesLabel.text = ""
  m.episodes.visible = false
  if r.u <> invalid and r.u <> "" then m.playUrl = r.u
  itemExt = ""
  if r.x <> invalid then itemExt = lowerCase(r.x.toStr())
  m.playItem = { id: m.top.itemId, k: m.top.contentKind, ext: itemExt }
  if m.top.contentKind = 1 or m.top.contentKind = 3
    queuePrebuffer({id: m.top.itemId, k: m.top.contentKind, u: r.u, x: itemExt, t: r.t, h: r.h})
  end if
  setFav(r.fav)
  paintButtons()
end sub

sub onLiveEpg(ev)
  r = ev.getData()
  if r = invalid or r.now = invalid then
    m.description.text = "Transmissão ao vivo de " + m.title.text + "."
    return
  end if
  if r.now.desc <> invalid and r.now.desc <> "" then
    m.description.text = r.now.desc.toStr()
    if r.now.title <> invalid and r.now.title <> "" then
      m.description.text = r.now.title.toStr() + " — " + m.description.text
    end if
  else
    m.description.text = "Transmissão ao vivo de " + m.title.text + "."
  end if
end sub

sub setCast(castList)
  m.cast.text = ""
  if castList = invalid then return
  names = []
  for each n in castList
    if n <> invalid and n <> "" then names.push(n.toStr())
  end for
  if names.Count() = 0 then return
  text = "Elenco: "
  for i = 0 to names.Count() - 1
    if i > 0 then text = text + ", "
    text = text + names[i]
    if i >= 3 then exit for
  end for
  m.cast.text = text
end sub

sub setFav(state)
  ' r.fav chega como Int (0/1) ou Boolean: comparar Int com String derruba o app
  ' com "Type Mismatch", então converte por tipo antes de decidir.
  fav = false
  if state = invalid then
    fav = false
  else if type(state) = "String" then
    fav = (state = "1" or lowerCase(state) = "true")
  else if type(state) = "Boolean" then
    fav = state
  else
    fav = (state <> 0)
  end if
  if fav then
    m.favLabel.text = "Na minha lista"
  else
    m.favLabel.text = "Minha lista"
  end if
end sub

sub toggleFav()
  if m.top.contentKind = invalid or m.top.itemId = invalid then return
  t = CreateObject("roSGNode", "ApiTask")
  t.url = m.api + "?a=fav&profile=" + m.scene.profileId
  t.postData = "kind=" + m.top.contentKind.toStr() + "&id=" + m.top.itemId.toStr()
  t.observeField("result", "onFavResult")
  t.observeField("error", "onFavError")
  t.control = "RUN"
end sub

sub onFavResult(ev)
  r = ev.getData()
  if r = invalid then return
  if r.fav <> invalid then
    setFav(r.fav)
    m.top.favoriteChanged = {id: m.top.itemId, kind: m.top.contentKind, fav: r.fav}
  else
    setFav(0)
  end if
end sub

sub onFavError(ev)
  print "[nav] fav error: " + ev.getData()
end sub

sub loadShow()
  request("?a=show&id=" + m.top.itemId.toStr(), "onShowResult", "onError")
end sub

sub onShowResult(ev)
  r = ev.getData()
  if r = invalid or r.show = invalid then
    m.title.text = "Não foi possível carregar"
    return
  end if
  s = r.show
  m.title.text = s.t
  meta = "Série"
  if s.y > 0 then meta = s.y.toStr() + " · " + meta
  if s.g <> invalid and s.g <> "" then meta = meta + " · " + s.g.toStr()
  m.meta.text = meta
  m.description.text = ""
  if s.o <> invalid and s.o <> "" then m.description.text = s.o
  if m.description.text = "" then m.description.text = "Sinopse não disponível para esta série."
  setCast(s.c)
  if s.p <> invalid then m.poster.uri = fitImg(absImg(s.p), 240, 360) else m.poster.uri = "pkg:/images/no-poster.png"
  setBackdrop(s.b, s.p)
  if s.g <> invalid then m.genres.text = s.g.toStr()
  setFav(s.fav)
  content = CreateObject("roSGNode", "ContentNode")
  row = content.CreateChild("ContentNode")
  count = 0
  for each season in r.seasons
    for each ep in season.eps
      row.CreateChild("ContentNode").update({ t: "S" + season.s.toStr() + "E" + ep.e.toStr() + "  " + ep.t,
        u: ep.u, id: ep.id, x: ep.x, h: ep.h }, true)
      count = count + 1
    end for
  end for
  m.episodesLabel.text = "Episódios (" + count.toStr() + ")"
  m.episodes.content = content
  m.episodes.visible = count > 0
  paintButtons()
end sub

sub onEpisodeSelected()
  f = m.episodes.rowItemFocused
  if f = invalid or f.Count() < 2 then return
  row = m.episodes.content.GetChild(f[0])
  if row = invalid then return
  ep = row.GetChild(f[1])
  if ep = invalid then return
  ext = ""
  if ep.x <> invalid then ext = lowerCase(ep.x.toStr())
  m.scene.callFunc("openPlayerItem", ep.id, 3, ext)
end sub

sub queuePrebuffer(item as object)
  if item = invalid or item.u = invalid or item.u = "" then return
  m.top.prebuffer = item
end sub

sub onScreenHidden()
  m.scene.callFunc("cancelPrebuffer")
end sub

function mediaTypeName(mediaKind) as string
  if mediaKind = 1 then return "Filme"
  if mediaKind = 0 then return "Ao vivo"
  if mediaKind = 3 then return "Episódio"
  return "Série"
end function

sub onError(ev)
  m.title.text = "Não foi possível carregar"
  print "[nav] details error: " + ev.getData()
end sub

sub startPlay()
  if m.top.contentKind = 2 then
    if m.episodes.visible then m.episodes.setFocus(true)
    return
  end if
  if m.playUrl <> "" then m.scene.callFunc("openPlayerItem", m.playItem.id, m.playItem.k, m.playItem.ext)
end sub

function onKeyEvent(key, press) as boolean
  if not press then return false
  key = LCase(key)
  ' Lista de episódios com foco: ela mesma trata setas/ok; "up" volta aos botões.
  if m.episodes.isInFocusChain()
    if key = "up"
      m.top.setFocus(true)
      paintButtons()
      return true
    end if
    return false
  end if
  if key = "up"
    m.scene.callFunc("focusTopBar")
    return true
  else if key = "down"
    if m.episodes.visible then m.episodes.setFocus(true)
    return true
  else if key = "left"
    if m.sel > 0
      m.sel = m.sel - 1
      paintButtons()
    end if
    return true
  else if key = "right"
    if m.sel < 2
      m.sel = m.sel + 1
      paintButtons()
    end if
    return true
  else if key = "ok" or key = "select"
    if m.sel = 1 then
      toggleFav()
    else if m.sel = 2 then
      m.expanded = not m.expanded
      if m.expanded then m.description.numLines = 11 else m.description.numLines = 4
    else
      startPlay()
    end if
    return true
  end if
  return false
end function

sub onFocusTimer()
  if m.top.isInFocusChain() then
    m.top.setFocus(true)
  end if
  paintButtons()
end sub

sub focusContent()
  if m.requested <> true then
    m.requested = true
    if m.top.contentKind = 2 then loadShow() else loadItem()
  end if
  m.top.setFocus(true)
  ' Longer delay to ensure UI nodes are ready and API has time to start
  m.focusTimer.duration = 0.5
  m.focusTimer.repeat = false
  m.focusTimer.control = "start"
end sub
